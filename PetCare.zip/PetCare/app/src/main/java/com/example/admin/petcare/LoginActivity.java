package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.petcare.Admin.Admin_home;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {

    EditText email, password;
    Button login, admin;
    TextView newUser, forgotPassword;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        email = findViewById(R.id.main_email);
        password = findViewById(R.id.main_pass);
        login = findViewById(R.id.main_login);
        newUser = findViewById(R.id.main_newuser);

        forgotPassword = findViewById(R.id.main_forgetpass);

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this, Forgot_password.class));
            }
        });

        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.getText().toString().trim().equals("")) {
                    email.setError("Email Id Required");
                } else if (password.getText().toString().trim().equals("")) {
                    password.setError("Password Required");
                } else {
                    /*sp.edit().putString(ConstantSp.ID,"11").commit();
                    sp.edit().putString(ConstantSp.NAME,"").commit();
                    sp.edit().putString(ConstantSp.EMAIL,"").commit();
                    sp.edit().putString(ConstantSp.C_NO,"").commit();
                    sp.edit().putString(ConstantSp.PASSWORD,"").commit();
                    sp.edit().putString(ConstantSp.ADDRESS,"").commit();
                    sp.edit().putString(ConstantSp.PINCODE,"").commit();
                    sp.edit().putString(ConstantSp.STATE,"").commit();
                    sp.edit().putString(ConstantSp.CITY,"").commit();
                    startActivity( new Intent( LoginActivity.this,HomeActivity.class ) );*/
                    if (new ConnectionDetector(LoginActivity.this).isConnectingToInternet()) {
                        new loginData().execute();
                    } else {
                        new ConnectionDetector(LoginActivity.this).connectiondetect();
                    }
                }
            }
        });


    }

    private class loginData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(LoginActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("email", email.getText().toString());
            hashMap.put("password", password.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "login.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(LoginActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    JSONArray jsonArray = object.getJSONArray("response");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        sp.edit().putString(ConstantSp.USERTYPE, jsonObject.getString("type")).commit();
                        sp.edit().putString(ConstantSp.ID, jsonObject.getString("id")).commit();
                        sp.edit().putString(ConstantSp.NAME, jsonObject.getString("name")).commit();
                        sp.edit().putString(ConstantSp.EMAIL, jsonObject.getString("email")).commit();
                        sp.edit().putString(ConstantSp.C_NO, jsonObject.getString("contact")).commit();
                        sp.edit().putString(ConstantSp.PASSWORD, jsonObject.getString("password")).commit();
                        sp.edit().putString(ConstantSp.ADDRESS, jsonObject.getString("address")).commit();
                        sp.edit().putString(ConstantSp.PINCODE, jsonObject.getString("pincode")).commit();
                        sp.edit().putString(ConstantSp.STATE, jsonObject.getString("state")).commit();
                        sp.edit().putString(ConstantSp.CITY, jsonObject.getString("city")).commit();
                        sp.edit().putString(ConstantSp.RESCUER, jsonObject.getString("rescuer")).commit();
                        if (jsonObject.getString("type").equalsIgnoreCase("Admin")) {
                            startActivity(new Intent(LoginActivity.this, Admin_home.class));
                        } else {
                            startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                        }

                    }
                } else {
                    Toast.makeText(LoginActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }
}

