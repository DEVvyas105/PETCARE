package com.example.admin.petcare.Admin;

public class AdminYouTubeVideos {

    String id;
    String videoUrl;

    public AdminYouTubeVideos(String id, String videoUrl) {
        this.id = id;
        this.videoUrl = videoUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
