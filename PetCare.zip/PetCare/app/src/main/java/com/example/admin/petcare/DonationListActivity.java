package com.example.admin.petcare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.petcare.Admin.AllFreePets;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class DonationListActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<DonationLists> arrayList;
    DonationAdapter adapter;
    FloatingActionButton floatingActionButton1;

    SharedPreferences sp;

    Button total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donation_list);
        getSupportActionBar().setTitle("Donation Lists");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        recyclerView = findViewById(R.id.donation_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(DonationListActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        floatingActionButton1 = findViewById(R.id.donation_fab1);
        total = findViewById(R.id.donation_list_total);

        floatingActionButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DonationListActivity.this, AddDonationActivity.class);
                startActivity(intent);
            }
        });

        if (sp.getString(ConstantSp.USERTYPE, "").equalsIgnoreCase("Admin")) {
            floatingActionButton1.setVisibility(View.GONE);
            total.setVisibility(View.VISIBLE);
        } else {
            floatingActionButton1.setVisibility(View.VISIBLE);
            total.setVisibility(View.GONE);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new ConnectionDetector(DonationListActivity.this).isConnectingToInternet()) {
            new getData().execute();
        } else {
            new ConnectionDetector(DonationListActivity.this).connectiondetect();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class getData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(DonationListActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("type", sp.getString(ConstantSp.USERTYPE, ""));
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getDonation.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    total.setText("Donation Total Amount : " + getResources().getString(R.string.rs_symbol) + object.getInt("total"));
                    arrayList = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        DonationLists lists = new DonationLists();
                        lists.setId(jsonObject.getString("id"));
                        lists.setName(jsonObject.getString("name"));
                        lists.setAmount(jsonObject.getString("amount"));
                        lists.setTransactionId(jsonObject.getString("transaction_id"));
                        lists.setDate(jsonObject.getString("created_date"));
                        arrayList.add(lists);
                    }
                    adapter = new DonationAdapter(DonationListActivity.this, arrayList);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(DonationListActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class DonationAdapter extends RecyclerView.Adapter<DonationAdapter.MyHolder> {

        Context context;
        ArrayList<DonationLists> arrayList;

        public DonationAdapter(DonationListActivity donationListActivity, ArrayList<DonationLists> arrayList) {
            this.context = donationListActivity;
            this.arrayList = arrayList;
        }

        @NonNull
        @Override
        public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_donate, parent, false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyHolder holder, int position) {
            holder.name.setText(arrayList.get(position).getName());
            holder.amount.setText(getResources().getString(R.string.rs_symbol) + arrayList.get(position).getAmount());
            holder.date.setText(arrayList.get(position).getDate());
            holder.transactionId.setText(arrayList.get(position).getTransactionId());
        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public class MyHolder extends RecyclerView.ViewHolder {

            TextView name, amount, date, transactionId;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.custom_donate_name);
                amount = itemView.findViewById(R.id.custom_donate_price);
                transactionId = itemView.findViewById(R.id.custom_donate_transaction_id);
                date = itemView.findViewById(R.id.custom_donate_date);
            }
        }
    }
}