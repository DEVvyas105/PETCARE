package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.admin.petcare.ui.home.TypeAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AllPetsTypesActivity extends AppCompatActivity {

    ListView petListview;
    ArrayList<AllPetsList> allPetsLists;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_pets_types);
        sp = getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);
        getSupportActionBar().setTitle(sp.getString(ConstantSp.TYPENAME,""));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        petListview= findViewById(R.id.petTypes);

        if(new ConnectionDetector(AllPetsTypesActivity.this).isConnectingToInternet()){
            new getData().execute();
        }
        else{
            new ConnectionDetector(AllPetsTypesActivity.this).connectiondetect();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    public class getData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AllPetsTypesActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("typeId",sp.getString(ConstantSp.TYPEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getPetTypeCategory.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    allPetsLists = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllPetsList list = new AllPetsList();
                        list.setId(jsonObject.getString("id"));
                        list.setImage(jsonObject.getString("image"));
                        list.setName(jsonObject.getString("name"));
                        list.setHeight(jsonObject.getString("height"));
                        list.setWeight(jsonObject.getString("weight"));
                        list.setLifespan(jsonObject.getString("lifespan"));
                        list.setPersonality(jsonObject.getString("personality"));
                        list.setHistory(jsonObject.getString("history"));
                        list.setDiet(jsonObject.getString("diet"));
                        allPetsLists.add(list);
                    }
                    TypeAdapter typeAdapter = new TypeAdapter(AllPetsTypesActivity.this,allPetsLists);
                    petListview.setAdapter((ListAdapter) typeAdapter);
                }
                else{
                    Toast.makeText(AllPetsTypesActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
