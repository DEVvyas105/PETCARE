package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.Admin.AllFreePets;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

class CustomFreeAdapter extends RecyclerView.Adapter<CustomFreeAdapter.MyHolder> {

    Context context;
    ArrayList<AllFreePets> allFreePets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public CustomFreeAdapter(Context context, ArrayList<AllFreePets> allFreePets) {
        this.context = context;
        this.allFreePets = allFreePets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pet_grid, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        holder.petName.setText(allFreePets.get(position).getPetname());
        holder.height.setText(allFreePets.get(position).getHeight() + " Inch");
        holder.weight.setText(allFreePets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allFreePets.get(position).getLifespan() + " Year");
        holder.name.setText(allFreePets.get(position).getName());
        holder.email.setText(allFreePets.get(position).getEmail());
        holder.contact.setText(allFreePets.get(position).getContactNo());

        if (allFreePets.get(position).getFromDate().equalsIgnoreCase("") && allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
            holder.dateLayout.setVisibility(View.GONE);
        } else {
            holder.dateLayout.setVisibility(View.VISIBLE);
            if (allFreePets.get(position).getFromDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getToDate());
            } else if (allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getFromDate());
            } else {
                holder.date.setText(allFreePets.get(position).getFromDate() + " To " + allFreePets.get(position).getToDate());
            }
        }

        holder.adopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allFreePets.get(position).getUserId().equalsIgnoreCase(sp.getString(ConstantSp.ID, ""))) {
                    Toast.makeText(context, "Its Your Pet", Toast.LENGTH_SHORT).show();
                } else {
                    sAdoptId = allFreePets.get(position).getId();
                    iPosition = position;
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        new adoptData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return allFreePets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact, date;
        Button adopt;
        LinearLayout dateLayout;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.pet_grid_petname);
            height = itemView.findViewById(R.id.pet_grid_height);
            weight = itemView.findViewById(R.id.pet_grid_wight);
            lifespan = itemView.findViewById(R.id.pet_grid_lifespan);
            name = itemView.findViewById(R.id.pet_grid_name);
            email = itemView.findViewById(R.id.pet_grid_email);
            contact = itemView.findViewById(R.id.pet_grid_contact);
            adopt = itemView.findViewById(R.id.pet_grid_adopt);
            date = itemView.findViewById(R.id.pet_grid_date);
            dateLayout = itemView.findViewById(R.id.pet_grid_date_layout);
        }
    }

    private class adoptData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sAdoptId);
            hashMap.put("adopt_userid", sp.getString(ConstantSp.ID, ""));
            hashMap.put("transactionId", "");
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateTransactionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    allFreePets.remove(iPosition);
                    notifyDataSetChanged();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
