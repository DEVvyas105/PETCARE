package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.Admin.AllPaidPets;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

class CustomPaidAdapter extends RecyclerView.Adapter<CustomPaidAdapter.MyHolder> {

    Context context;
    ArrayList<AllPaidPets> allPaidPets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public CustomPaidAdapter(Context context, ArrayList<AllPaidPets> allPaidPets) {
        this.context = context;
        this.allPaidPets = allPaidPets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public CustomPaidAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pet_paid_grid, parent, false);
        return new CustomPaidAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomPaidAdapter.MyHolder holder, final int position) {
        holder.petName.setText(allPaidPets.get(position).getPetname() + " ( " + context.getResources().getString(R.string.rs_symbol) + allPaidPets.get(position).getPrice() + " )");
        holder.height.setText(allPaidPets.get(position).getHeight() + " Inch");
        holder.weight.setText(allPaidPets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allPaidPets.get(position).getLifespan() + " Year");
        holder.name.setText(allPaidPets.get(position).getName());
        holder.email.setText(allPaidPets.get(position).getEmail());
        holder.contact.setText(allPaidPets.get(position).getContactNo());

        holder.adopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (allPaidPets.get(position).getUserId().equalsIgnoreCase(sp.getString(ConstantSp.ID, ""))) {
                    Toast.makeText(context, "Its Your Pet", Toast.LENGTH_SHORT).show();
                } else {
                    sAdoptId = allPaidPets.get(position).getId();
                    iPosition = position;
                    sp.edit().putString(ConstantSp.ADOPTID, allPaidPets.get(position).getId()).commit();
                    sp.edit().putString(ConstantSp.ADOPTPOSITION, String.valueOf(position)).commit();
                    sp.edit().putString(ConstantSp.ADOPTPRICE, allPaidPets.get(position).getPrice()).commit();
                    sp.edit().putString(ConstantSp.ADOPTPETNAME, allPaidPets.get(position).getPetname()).commit();
                    //context.startActivity(new Intent(context, AddPaymentActivity.class));
                    //launchPaymentFlow(allPaidPets.get(position).getPrice());
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        new adoptData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return allPaidPets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact;
        Button adopt;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.pet_paid_grid_petname);
            height = itemView.findViewById(R.id.pet_paid_grid_height);
            weight = itemView.findViewById(R.id.pet_paid_grid_wight);
            lifespan = itemView.findViewById(R.id.pet_paid_grid_lifespan);
            name = itemView.findViewById(R.id.pet_paid_grid_name);
            email = itemView.findViewById(R.id.pet_paid_grid_email);
            contact = itemView.findViewById(R.id.pet_paid_grid_contact);
            adopt = itemView.findViewById(R.id.pet_paid_grid_adopt);
        }
    }

    private class adoptData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sp.getString(ConstantSp.ADOPTID, ""));
            hashMap.put("adopt_userid", sp.getString(ConstantSp.ID, ""));
            hashMap.put("adopt_username", sp.getString(ConstantSp.NAME, ""));
            hashMap.put("transactionId", "");
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateTransactionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    //onBackPressed();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
