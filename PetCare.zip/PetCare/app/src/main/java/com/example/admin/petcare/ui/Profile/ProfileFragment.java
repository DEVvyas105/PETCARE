package com.example.admin.petcare.ui.Profile;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AppCompatActivity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.admin.petcare.AboutUs;
import com.example.admin.petcare.Change_password;
import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.ContactUs;
import com.example.admin.petcare.DonationListActivity;
import com.example.admin.petcare.Feedback;
import com.example.admin.petcare.LoginActivity;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.NewCaseActivity;
import com.example.admin.petcare.PetHistoryActivity;
import com.example.admin.petcare.R;
import com.example.admin.petcare.Update_profile;
import com.example.admin.petcare.buy.DashboardActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

public class ProfileFragment extends Fragment {


    SharedPreferences sp;
    ListView profile_Listview;
    Button logout;

    String[] pets = {"Update Profile", "About Us", "Feedback", "Contact Us", "Change Password", "Pet Adobtion History", "Donation", "New Case", "Become Resuer", "Shopping","Nearest Hospital"};
    int[] arr = {R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white};

    String[] pets_resc = {"Update Profile", "About Us", "Feedback", "Contact Us", "Change Password", "Pet Adobtion History", "Donation", "New Case", "Shopping","Nearest Hospital"};
    int[] arr_resc = {R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white, R.drawable.white};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();


        sp = ((AppCompatActivity) getActivity()).getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        profile_Listview = root.findViewById(R.id.profile_list);
        logout = root.findViewById(R.id.profile_logout);

        if (sp.getString(ConstantSp.RESCUER, "").equalsIgnoreCase("Yes")) {
            ProfileAdapter profileAdapter = new ProfileAdapter(getActivity(), pets_resc, arr_resc);
            profile_Listview.setAdapter((ListAdapter) profileAdapter);
        } else {
            ProfileAdapter profileAdapter = new ProfileAdapter(getActivity(), pets, arr);
            profile_Listview.setAdapter((ListAdapter) profileAdapter);
        }

        profile_Listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int itemPosition = position;

                switch (position) {
                    case 0:
                        Intent intent = new Intent(getActivity(), Update_profile.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent2 = new Intent(getActivity(), AboutUs.class);
                        startActivity(intent2);
                        break;
                    case 2:
                        Intent intent3 = new Intent(getActivity(), Feedback.class);
                        startActivity(intent3);
                        break;
                    case 3:
                        Intent intent4 = new Intent(getActivity(), ContactUs.class);
                        startActivity(intent4);
                        break;
                    case 4:
                        Intent intent5 = new Intent(getActivity(), Change_password.class);
                        startActivity(intent5);
                        break;
                    case 5:
                        Intent intent6 = new Intent(getActivity(), PetHistoryActivity.class);
                        startActivity(intent6);
                        break;
                    case 6:
                        startActivity(new Intent(getActivity(), DonationListActivity.class));
                        break;
                    case 7:
                        startActivity(new Intent(getActivity(), NewCaseActivity.class));
                        break;
                    case 8:
                        if (sp.getString(ConstantSp.RESCUER, "").equalsIgnoreCase("Yes")) {
                            startActivity(new Intent(getActivity(), DashboardActivity.class));
                        } else {
                            if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                                new addRescuer().execute();
                            } else {
                                new ConnectionDetector(getActivity()).connectiondetect();
                            }
                        }
                        break;
                    case 9:
                        if (sp.getString(ConstantSp.RESCUER, "").equalsIgnoreCase("Yes")) {
                            Uri gmmIntentUriHospital = Uri.parse("geo:0,0?q=Animal Hospital");
                            Intent mapIntentHospital = new Intent(Intent.ACTION_VIEW, gmmIntentUriHospital);
                            mapIntentHospital.setPackage("com.google.android.apps.maps");
                            startActivity(mapIntentHospital);
                        } else {
                            startActivity(new Intent(getActivity(), DashboardActivity.class));
                        }
                        break;
                    case 10:
                        Uri gmmIntentUriHospital = Uri.parse("geo:0,0?q=Animal Hospital");
                        Intent mapIntentHospital = new Intent(Intent.ACTION_VIEW, gmmIntentUriHospital);
                        mapIntentHospital.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntentHospital);
                        break;
                }
            }
            // ListView Clicked item value
            //String  itemValue    = (String) profile_Listview.getItemAtPosition(position);


            //Toast.makeText(getActivity(), "Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG).show(); }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().clear().commit();
                startActivity(new Intent(getActivity(), LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));

            }
        });
        return root;
    }

    private class addRescuer extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addRescuer.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_LONG).show();
                    sp.edit().putString(ConstantSp.RESCUER, "Yes").commit();
                    ProfileAdapter profileAdapter = new ProfileAdapter(getActivity(), pets_resc, arr_resc);
                    profile_Listview.setAdapter((ListAdapter) profileAdapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}