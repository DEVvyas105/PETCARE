package com.example.admin.petcare.buy;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class DetailAdapter extends RecyclerView.Adapter<DetailAdapter.MyHolder> {


    Context context;
    ArrayList<DetailList> detailLists;
    LayoutInflater layoutInflater;

    public DetailAdapter(DetailActivity detailActivity, ArrayList<DetailList> detailLists) {

        this.context = detailActivity;
        this.detailLists = detailLists;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_detail, viewGroup, false);
        return new DetailAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int i) {
        Picasso.with(context).load(detailLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(holder.iv);
        holder.name.setText(detailLists.get(i).getName());
        holder.price.setText(detailLists.get(i).getPrice());
    }

    @Override
    public int getItemCount() {
        return detailLists.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView name,price;
        ImageView iv;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.custom_detail_name);
            price = itemView.findViewById(R.id.custom_detail_price);
            iv = itemView.findViewById(R.id.custom_detail_iv);
        }
    }
    /*@Override
    public int getCount() {
        return detailLists.size();
    }

    @Override
    public Object getItem(int i) {
        return detailLists.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.custom_detail,null);

        //TextView description = view.findViewById(R.id.custom_detail_discription);
        //TextView power = view.findViewById(R.id.custom_detail_power);
        TextView price = view.findViewById(R.id.custom_detail_price);
        //ImageView iv = view.findViewById(R.id.custom_detail_iv);
        TextView name = view.findViewById(R.id.custom_detail_name);



        name.setText(detailLists.get(i).getName());
        price.setText(detailLists.get(i).getPrice());
        return view;
    }*/

}