package com.example.admin.petcare.Admin;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.admin.petcare.R;

public class Admin_feedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_feedback);



    }
}
