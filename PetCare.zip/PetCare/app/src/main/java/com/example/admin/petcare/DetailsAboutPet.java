package com.example.admin.petcare;


import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class DetailsAboutPet extends AppCompatActivity {

    /*size,size_detail,*/
    TextView name, name_detail, height, height_detail, weight, weight_detail, lifespan, lifespan_detail, personality, personality_detail, history, histroy_detail, diet, diet_detail;
    SharedPreferences sp;
    ImageView iv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_about_pet);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        getSupportActionBar().setTitle(sp.getString(ConstantSp.PETNAME, ""));

        iv = findViewById(R.id.pet_image);
        name = findViewById(R.id.name);
        name_detail = findViewById(R.id.name_detail);
        /*size=findViewById(R.id.size);
        size_detail=findViewById(R.id.size_detail);*/
        height = findViewById(R.id.height);
        height_detail = findViewById(R.id.height_detail);
        weight = findViewById(R.id.weight);
        weight_detail = findViewById(R.id.weight_detail);
        lifespan = findViewById(R.id.lifespan);
        lifespan_detail = findViewById(R.id.lifespan_detail);
        personality = findViewById(R.id.personality);
        personality_detail = findViewById(R.id.personality_detail);
        history = findViewById(R.id.history);
        histroy_detail = findViewById(R.id.history_detail);
        diet = findViewById(R.id.diet);
        diet_detail = findViewById(R.id.diet_detail);

        name_detail.setText(sp.getString(ConstantSp.PETNAME, ""));
        Picasso.with(DetailsAboutPet.this).load(ConstantSp.IMAGEURL + sp.getString(ConstantSp.PETIMAGE, "")).placeholder(R.drawable.logo).into(iv);
        height_detail.setText(sp.getString(ConstantSp.PETHEIGHT, ""));
        weight_detail.setText(sp.getString(ConstantSp.PETWEIGHT, ""));
        lifespan_detail.setText(sp.getString(ConstantSp.PETLIFESPAN, ""));
        personality_detail.setText(sp.getString(ConstantSp.PETPERSONALITY, ""));
        histroy_detail.setText(sp.getString(ConstantSp.PETHISTORY, ""));
        diet_detail.setText(sp.getString(ConstantSp.PETDIET, ""));

        /*if(new ConnectionDetector(DetailsAboutPet.this).isConnectingToInternet()){
            new getData().execute();
        }
        else{
            new ConnectionDetector(DetailsAboutPet.this).connectiondetect();
        }*/

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    /*class getData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(DetailsAboutPet.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("id",sp.getString(ConstantSp.PRODUCTId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getPetDetails.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        name_detail.setText(jsonObject.getString("name"));
                        Picasso.with(DetailsAboutPet.this).load(ConstantSp.IMAGEURL + jsonObject.getString("image")).placeholder(R.drawable.logo).into(iv);
                        size_detail.setText(jsonObject.getString("size"));
                        height_detail.setText(jsonObject.getString("height"));
                        weight_detail.setText(jsonObject.getString("weight"));
                        lifespan_detail.setText(jsonObject.getString("lifespan"));
                        personality_detail.setText(jsonObject.getString("personality"));
                        histroy_detail.setText(jsonObject.getString("history"));
                        diet_detail.setText(jsonObject.getString("diet"));
                    }
                }
                else{
                    Toast.makeText(DetailsAboutPet.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }*/

}
