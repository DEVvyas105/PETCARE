package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class AllRemedyDetails extends AppCompatActivity {

     TextView title,content;
     SharedPreferences sp;
     ImageButton back;
     ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_remedy_details);
        getSupportActionBar().hide();
        sp=getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);
        title = findViewById(R.id.all_remedy_details_title);
        content = findViewById(R.id.all_remedy_details_remedy);
        back = findViewById(R.id.all_remedy_details_back);
        imageView = findViewById(R.id.all_remedy_details_image);

        title.setText(sp.getString(ConstantSp.REMEDYNAME,""));
        content.setText(sp.getString(ConstantSp.REMEDYCONTENT,""));

        Picasso.with(AllRemedyDetails.this).load(ConstantSp.IMAGEURL + sp.getString(ConstantSp.REMEDYIMAGE,"")).placeholder(R.drawable.logo).into(imageView);

        /*if(new ConnectionDetector(AllRemedyDetails.this).isConnectingToInternet()){
            new getremedyDetails().execute();
        }
        else{
            new ConnectionDetector(AllRemedyDetails.this).connectiondetect();
        }*/


        back=findViewById(R.id.all_remedy_details_back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    /*private class getremedyDetails extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AllRemedyDetails.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("id",sp.getString(ConstantSp.REMEDYId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getRemedyDetails.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){

                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        tv.setText(jsonObject.getString("content"));
                    }
                }
                else{
                    Toast.makeText(AllRemedyDetails.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }*/

}
