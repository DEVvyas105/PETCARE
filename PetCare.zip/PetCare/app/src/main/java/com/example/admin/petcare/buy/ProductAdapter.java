package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyHolder> {

    Context context;
    ArrayList<ProductList> productLists;
    LayoutInflater layoutInflater;
    SharedPreferences sp;
    int iPosition;
    String sId;

    public ProductAdapter(ProductActivity productActivity, ArrayList<ProductList> productLists) {

        this.context = productActivity;
        this.productLists = productLists;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.product_category, viewGroup, false);
        return new ProductAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int i) {
        holder.name.setText(productLists.get(i).getName());
        holder.description.setText(productLists.get(i).getDiscription());
        holder.quantity.setText(productLists.get(i).getQuantity());
        holder.price.setText("Rs." + productLists.get(i).getPrice());
        Picasso.with(context).load(productLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(holder.iv);

        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTID, productLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.PRODUCTNAME, productLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.PRODUCTDESCRIPTION, productLists.get(i).getDiscription()).commit();
                sp.edit().putString(ConstantSp.PRODUCTQUANTITY, productLists.get(i).getQuantity()).commit();
                sp.edit().putString(ConstantSp.PRODUCTPRICE, productLists.get(i).getPrice()).commit();
                sp.edit().putString(ConstantSp.PRODUCTIMAGE, productLists.get(i).getImage()).commit();
                context.startActivity(new Intent(context, ShowActivity.class));
            }
        });

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCT_ADD_UPDATE, "Edit").commit();
                sp.edit().putString(ConstantSp.PRODUCTID, productLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.PRODUCTNAME, productLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.PRODUCTDESCRIPTION, productLists.get(i).getDiscription()).commit();
                sp.edit().putString(ConstantSp.PRODUCTQUANTITY, productLists.get(i).getQuantity()).commit();
                sp.edit().putString(ConstantSp.PRODUCTPRICE, productLists.get(i).getPrice()).commit();
                sp.edit().putString(ConstantSp.PRODUCTIMAGE, productLists.get(i).getImage()).commit();
                context.startActivity(new Intent(context, AddProductActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        if (sp.getString(ConstantSp.USERTYPE, "").equals("Admin")) {
            holder.addtocart.setVisibility(View.GONE);
            holder.edit.setVisibility(View.VISIBLE);
            holder.delete.setVisibility(View.VISIBLE);
            //holder.wishlist.setVisibility(View.GONE);
        } else {
            holder.addtocart.setVisibility(View.VISIBLE);
            holder.edit.setVisibility(View.GONE);
            holder.delete.setVisibility(View.GONE);
            //holder.wishlist.setVisibility(View.VISIBLE);
        }
        /*holder.wishlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTID,productLists.get(i).getId()).commit();
                if(new ConnectionDetector(context).isConnectingToInternet()){
                    new wishList().execute();
                }
                else{
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });*/
        holder.addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTID, productLists.get(i).getId()).commit();
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    new addCart().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    iPosition = i;
                    sId = productLists.get(i).getId();
                    new deleteData().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return productLists.size();
    }

    private class deleteData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sId);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteCategoryProduct.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    productLists.remove(iPosition);
                    notifyDataSetChanged();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /*@Override
    public int getCount() {
        return productLists.size();
    }

    @Override
    public Object getItem(int i) {
        return productLists.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        view = layoutInflater.inflate(R.layout.product_category,null);

        TextView description = view.findViewById(R.id.custom_product_discription);
        TextView quantity = view.findViewById(R.id.custom_product_quantity);
        TextView price = view.findViewById(R.id.custom_product_price);
        ImageView iv = view.findViewById(R.id.custom_product_iv);
        TextView name = view.findViewById(R.id.custom_product_name);
        ImageView wishlist = view.findViewById(R.id.custom_product_wishlist);
        ImageView addtocart = view.findViewById(R.id.custom_product_add_to_cart);

        Picasso.with(context).load(productLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(iv);
        //iv.setImageResource(productLists.get(i).getImage());
        name.setText(productLists.get(i).getName());
        description.setText(productLists.get(i).getDiscription());
        quantity.setText(productLists.get(i).getQuantity());
        price.setText(productLists.get(i).getPrice());




        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTID,productLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.PRODUCTNAME,productLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.PRODUCTDESCRIPTION,productLists.get(i).getDiscription()).commit();
                sp.edit().putString(ConstantSp.PRODUCTQUANTITY,productLists.get(i).getQuantity()).commit();
                sp.edit().putString(ConstantSp.PRODUCTPRICE,productLists.get(i).getPrice()).commit();
                sp.edit().putString(ConstantSp.PRODUCTIMAGE,productLists.get(i).getImage()).commit();
                context.startActivity(new Intent(context, ShowActivity.class));
            }
        });
        return view;
    }
*/
    private class addCart extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("quantity", "1");
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            hashMap.put("product_id", sp.getString(ConstantSp.PRODUCTID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addcart.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }
/*
    private class wishList extends AsyncTask<String,String,String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("userId",sp.getString(ConstantSp.USERID,""));
            hashMap.put("product_id",sp.getString(ConstantSp.PRODUCTID,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"wishlist.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }*/

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView name, description, quantity, price, edit, delete;
        ImageView iv, addtocart;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.custom_product_name);
            description = itemView.findViewById(R.id.custom_product_discription);
            quantity = itemView.findViewById(R.id.custom_product_quantity);
            price = itemView.findViewById(R.id.custom_product_price);
            iv = itemView.findViewById(R.id.custom_product_iv);
            //wishlist = itemView.findViewById(R.id.custom_product_wishlist);
            addtocart = itemView.findViewById(R.id.custom_product_add_to_cart);
            edit = itemView.findViewById(R.id.custom_product_edit);
            delete = itemView.findViewById(R.id.custom_product_delete);
        }
    }
}
