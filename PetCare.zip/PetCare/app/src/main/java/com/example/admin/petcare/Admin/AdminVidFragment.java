package com.example.admin.petcare.Admin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Vector;

public class AdminVidFragment extends Fragment {

    public AdminVidFragment() {

    }

    RecyclerView recyclerView;
    Vector<AdminYouTubeVideos> youtubeVideos = new Vector<AdminYouTubeVideos>();

    FloatingActionButton add;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.admin_vid_layout, container, false);

        recyclerView = (RecyclerView) root.findViewById(R.id.admin_recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        add = root.findViewById(R.id.admin_vid_fab1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AddAdminVideoActivity.class));
            }
        });
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getVideoData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
    }

    private class getVideoData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getVideo.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        youtubeVideos.add(new AdminYouTubeVideos(jsonObject.getString("id"), " < iframe width =\"100%\" height=\"100%\" src=\"" + jsonObject.getString("video") + "\" frameborder=\"0\" allowfullscreen></iframe>"));
                    }
                    AdminVideoAdapter videoAdapter = new AdminVideoAdapter(getActivity(), youtubeVideos);
                    recyclerView.setAdapter(videoAdapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class AdminVideoAdapter extends RecyclerView.Adapter<AdminVideoAdapter.VideoViewHolder> {

        Vector<AdminYouTubeVideos> youtubeVideoList;
        Context context;
        int iPosition;
        String sId;

        public AdminVideoAdapter(Context context, Vector<AdminYouTubeVideos> youtubeVideoList) {
            this.context = context;
            this.youtubeVideoList = youtubeVideoList;
        }

        @Override
        public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.admin_video_view, parent, false);
            return new VideoViewHolder(view);

        }

        @Override
        public void onBindViewHolder(VideoViewHolder holder, final int position) {
            holder.videoWeb.loadData(youtubeVideoList.get(position).getVideoUrl(), "text/html", "utf-8");
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sId = youtubeVideoList.get(position).getId();
                    iPosition = position;
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });
        }


        @Override
        public int getItemCount() {
            return youtubeVideoList.size();
        }

        public class VideoViewHolder extends RecyclerView.ViewHolder {

            WebView videoWeb;
            ImageView delete;

            public VideoViewHolder(View itemView) {
                super(itemView);

                videoWeb = (WebView) itemView.findViewById(R.id.admin_videoWebView);
                delete = itemView.findViewById(R.id.admin_video_view_delete);
                videoWeb.getSettings().setJavaScriptEnabled(true);
                videoWeb.setWebChromeClient(new WebChromeClient() {
                });
            }
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteVideo.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                        youtubeVideoList.remove(iPosition);
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}

