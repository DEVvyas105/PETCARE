package com.example.admin.petcare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class NewCaseActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<NewCaseLists> arrayList;
    NewCaseAdapter adapter;
    FloatingActionButton floatingActionButton1;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_case);
        getSupportActionBar().setTitle("New Case Lists");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        recyclerView = findViewById(R.id.new_case_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(NewCaseActivity.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        floatingActionButton1 = findViewById(R.id.new_case_fab1);

        floatingActionButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewCaseActivity.this, AddNewCaseActivity.class);
                startActivity(intent);
            }
        });

        if (sp.getString(ConstantSp.USERTYPE, "").equalsIgnoreCase("Admin")) {
            floatingActionButton1.setVisibility(View.GONE);
        } else {
            floatingActionButton1.setVisibility(View.VISIBLE);
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new ConnectionDetector(NewCaseActivity.this).isConnectingToInternet()) {
            new getData().execute();
        } else {
            new ConnectionDetector(NewCaseActivity.this).connectiondetect();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class getData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(NewCaseActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            if (sp.getString(ConstantSp.RESCUER, "").equalsIgnoreCase("Yes")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("userId", "");
                hashMap.put("rescuer_id", sp.getString(ConstantSp.ID, ""));
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getNewCase.php", MakeServiceCall.POST, hashMap);
            } else {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
                hashMap.put("rescuer_id", "");
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getNewCase.php", MakeServiceCall.POST, hashMap);
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    arrayList = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        NewCaseLists lists = new NewCaseLists();
                        lists.setId(jsonObject.getString("id"));
                        lists.setUserId(jsonObject.getString("userId"));
                        lists.setName(jsonObject.getString("name"));
                        lists.setAddress(jsonObject.getString("address"));
                        lists.setImage(jsonObject.getString("image"));
                        lists.setRescuerId(jsonObject.getString("rescuer_id"));
                        lists.setRescuerName(jsonObject.getString("rescuer_name"));
                        lists.setDate(jsonObject.getString("created_date"));
                        arrayList.add(lists);
                    }
                    adapter = new NewCaseAdapter(NewCaseActivity.this, arrayList);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(NewCaseActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class NewCaseAdapter extends RecyclerView.Adapter<NewCaseAdapter.MyHolder> {

        Context context;
        ArrayList<NewCaseLists> arrayList;
        String sCaseId;

        public NewCaseAdapter(NewCaseActivity newCaseActivity, ArrayList<NewCaseLists> arrayList) {
            this.context = newCaseActivity;
            this.arrayList = arrayList;
        }

        @NonNull
        @Override
        public NewCaseAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_new_case, parent, false);
            return new NewCaseAdapter.MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull NewCaseAdapter.MyHolder holder, final int position) {
            holder.name.setText(arrayList.get(position).getName());
            holder.address.setText(arrayList.get(position).getAddress());
            holder.date.setText(arrayList.get(position).getDate());
            holder.rescuerName.setText(arrayList.get(position).getRescuerName());
            Picasso.with(context).load(ConstantSp.IMAGEURL + arrayList.get(position).getImage()).placeholder(R.drawable.logo).into(holder.imageView);

            if (arrayList.get(position).getRescuerId().equals("")) {
                holder.rescuerLayout.setVisibility(View.GONE);
                if (sp.getString(ConstantSp.RESCUER, "").equalsIgnoreCase("Yes")) {
                    holder.rescue.setVisibility(View.VISIBLE);
                } else {
                    holder.rescue.setVisibility(View.GONE);
                }
            } else {
                holder.rescuerLayout.setVisibility(View.VISIBLE);
                holder.rescue.setVisibility(View.GONE);
            }

            holder.rescue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sCaseId = arrayList.get(position).getId();
                        new addRescue().execute();
                    } else {
                        new ConnectionDetector(NewCaseActivity.this).connectiondetect();
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        public class MyHolder extends RecyclerView.ViewHolder {

            TextView name, address, rescuerName, date, rescue;
            ImageView imageView;
            LinearLayout rescuerLayout;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.custom_new_case_name);
                address = itemView.findViewById(R.id.custom_new_case_address);
                rescuerName = itemView.findViewById(R.id.custom_new_case_rescuer_name);
                rescue = itemView.findViewById(R.id.custom_new_case_rescue);
                date = itemView.findViewById(R.id.custom_new_case_date);
                imageView = itemView.findViewById(R.id.custom_new_case_image);
                rescuerLayout = itemView.findViewById(R.id.custom_new_case_rescuer_layout);
            }
        }

        private class addRescue extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setCancelable(false);
                pd.setMessage("Please Wait...");
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sCaseId);
                hashMap.put("rescuer_id", sp.getString(ConstantSp.ID, ""));
                hashMap.put("rescuer_name", sp.getString(ConstantSp.NAME, ""));
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateRescuerCase.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                        context.startActivity(new Intent(context, NewCaseActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}