package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class OwnPetsFragment extends Fragment {

    SharedPreferences sp;
    RecyclerView freeGrid;
    ArrayList<OwnPetsList> allFreePets;

    public OwnPetsFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_own_pets, container, false);

        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

        // Inflate the layout for this fragment
        freeGrid = root.findViewById(R.id.own_pets_grid);
        freeGrid.setLayoutManager(new LinearLayoutManager(getActivity()));
        freeGrid.setItemAnimator(new DefaultItemAnimator());

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getOwnData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
        return root;
    }


    private class getOwnData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("user_id", sp.getString(ConstantSp.ID, ""));
            hashMap.put("type", "Own");
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getOwnAdoptionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    allFreePets = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        OwnPetsList list = new OwnPetsList();
                        list.setId(jsonObject.getString("id"));
                        list.setUserId(jsonObject.getString("userId"));
                        list.setName(jsonObject.getString("u_name"));
                        list.setEmail(jsonObject.getString("u_email"));
                        list.setContactNo(jsonObject.getString("u_cno"));
                        list.setHeight(jsonObject.getString("u_height"));
                        list.setWeight(jsonObject.getString("u_weight"));
                        list.setLifespan(jsonObject.getString("u_lifespan"));
                        list.setPetname(jsonObject.getString("u_petname"));
                        list.setPrice(jsonObject.getString("u_prize"));
                        list.setType(jsonObject.getString("u_type"));
                        list.setFromDate(jsonObject.getString("u_from"));
                        list.setToDate(jsonObject.getString("u_to"));
                        list.setAdoptUserId(jsonObject.getString("adopt_userid"));
                        list.setAdopted_username(jsonObject.getString("adopt_username"));
                        list.setTransactionId(jsonObject.getString("transactionId"));
                        allFreePets.add(list);
                    }
                    OwnPetsAdapter adapter = new OwnPetsAdapter(getActivity(), allFreePets);
                    freeGrid.setAdapter(adapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
