package com.example.admin.petcare.ui.Video;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.MyHolder> {

    Context context;
    ArrayList<AllArticles> allArticles;
    SharedPreferences sp;

    public ArticleAdapter(Context activity, ArrayList<AllArticles> allArticles) {
        this.context = activity;
        this.allArticles = allArticles;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_article, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        holder.t1.setText(allArticles.get(position).getTitle());
        holder.t2.setText(allArticles.get(position).getContent());
    }

    @Override
    public int getItemCount() {
        return allArticles.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView t1, t2;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            t1 = itemView.findViewById(R.id.c_t1);
            t2 = itemView.findViewById(R.id.c_t2);
        }
    }
}
