package com.example.admin.petcare;

public class ConstantSp {
    /*public static final String URL="https://petcare2020.000webhostapp.com/";
    public static final String IMAGEURL = "https://petcare2020.000webhostapp.com/images/";*/

    /*public static final String URL = "http://hd-infotech.com/AndroidStudentProject/PetCare/";
    public static final String IMAGEURL = "http://hd-infotech.com/AndroidStudentProject/PetCare/images/";*/

    public static final String URL = "https://mentormate.000webhostapp.com/PetCare/";
    //public static final String URL = "http://hd-infotech.com/AndroidStudentProject/PetCare/";
    public static final String IMAGEURL = ConstantSp.URL + "images/";

    public static final String MONEY_HASH = ConstantSp.URL + "PayUMoneyHash.php";

    public static final String SURL = "https://www.payumoney.com/mobileapp/payumoney/success.php";
    public static final String FURL = "https://www.payumoney.com/mobileapp/payumoney/failure.php";
    public static final String MERCHANT_KEY = "5qKzs5qx";
    public static final String MERCHANT_ID = "7252061";
    public static final boolean DEBUG = true;

    public static final String DEFAULT_MAIL = "admin@gmail.com";

    public static final String PREF = "pref";
    public static final String ID = "id";
    public static final String USERTYPE = "usertype";
    public static final String NAME = "name";
    public static final String EMAIL = "email";
    public static final String ADDRESS = "address";
    public static final String C_NO = "contact";
    public static final String STATE = "state";
    public static final String CITY = "city";
    public static final String PASSWORD = "password";
    public static final String PINCODE = "pincode";
    public static final String RESCUER = "rescuer";

    public static final String TYPEId = "type_id";
    public static final String TYPENAME = "type_name";

    public static final String PRODUCTId = "product_id";
    public static final String PETNAME = "petname";
    public static final String PETIMAGE = "petimage";
    public static final String PETHEIGHT = "petheight";
    public static final String PETWEIGHT = "petweight";
    public static final String PETLIFESPAN = "petlifespan";
    public static final String PETPERSONALITY = "petpersonality";
    public static final String PETHISTORY = "pethistory";
    public static final String PETDIET = "petdiet";

    public static final String REMEDYId = "remedy_id";
    public static final String REMEDYNAME = "remedy_name";
    public static final String REMEDYIMAGE = "remedy_image";
    public static final String REMEDYCONTENT = "remedy_content";

    public static final String FREEId = "free_id";
    public static final String PAIDId = "paid_id";
    public static final String ADOPTIONId = "adopt_id";

    public static final String ADOPTID = "adopt_id";
    public static final String ADOPTUSERID = "adopt_user_id";
    public static final String ADOPTUSERNAME = "adopt_user_name";
    public static final String ADOPTPOSITION = "adopt_position";
    public static final String ADOPTPRICE = "adopt_price";
    public static final String ADOPTPETNAME = "adopt_pet_name";

    public static final String FEES = "fees";

    public static final String TOTAL = "total";
    public static final String SELECTMETHOD = "selectmethod";
    /* public static final String USER_TYPE = "user_type";*/

    /* public static final String USERID = "userid";*/
    public static final String CATEGORY_ADD_UPDATE = "category_add_update";
    public static final String CATEGORYID = "categoryid";
    public static final String CATEGORYNAME = "categoryname";
    public static final String CATEGORYIMAGE = "categoryimage";

    public static final String ORDERID = "orderid";
    public static final String SEARCH = "search";

    public static final String PRODUCT_ADD_UPDATE = "product_add_update";
    public static final String PRODUCTID = "productid";
    public static final String PRODUCTNAME = "productname";
    public static final String PRODUCTDESCRIPTION = "productdiscription";
    public static final String PRODUCTQUANTITY = "productquantity";
    public static final String PRODUCTPRICE = "productprice";
    public static final String PRODUCTIMAGE = "productimage";

    public static final String SHIPPINGID = "shippingid";
    public static final String TRANSACTIONID = "transactionid";

    public static final String AREA = "area";
}
