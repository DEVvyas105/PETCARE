package com.example.admin.petcare.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.admin.petcare.AllRemedyDetails;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RemedyAdapter extends RecyclerView.Adapter<RemedyAdapter.MyViewHolder> {

    public LayoutInflater inflater;
    Context context;
    private ArrayList<RemedyModel> imageModelArrayList1;
    SharedPreferences sp;

    public RemedyAdapter(Context context, ArrayList<RemedyModel> imageModelArrayList1) {
        inflater = LayoutInflater.from(context);
        this.imageModelArrayList1=imageModelArrayList1;
        this.context=context;
        sp = context.getSharedPreferences(ConstantSp.PREF,Context.MODE_PRIVATE);

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = inflater.inflate(R.layout.remedy_item, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {

        Picasso.with(context).load(ConstantSp.IMAGEURL + imageModelArrayList1.get(position).getImage()).placeholder(R.drawable.logo).into(holder.iv);
        //holder.iv.setImageResource(imageModelArrayList1.get(position).getImage());
        holder.time.setText(imageModelArrayList1.get(position).getName());

        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putString(ConstantSp.REMEDYId,imageModelArrayList1.get(position).getId()).commit();
                sp.edit().putString(ConstantSp.REMEDYNAME,imageModelArrayList1.get(position).getName()).commit();
                sp.edit().putString(ConstantSp.REMEDYIMAGE,imageModelArrayList1.get(position).getImage()).commit();
                sp.edit().putString(ConstantSp.REMEDYCONTENT,imageModelArrayList1.get(position).getContent()).commit();
                Intent intent = new Intent(context, AllRemedyDetails.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageModelArrayList1.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        RemedyModel remedyModel = new RemedyModel();

        TextView time;
        ImageView iv;

        public MyViewHolder(View itemView) {
            super(itemView);

            time = (TextView) itemView.findViewById(R.id.remedy_name);
            iv = (ImageView) itemView.findViewById(R.id.remedy_img);

        }

    }
}
