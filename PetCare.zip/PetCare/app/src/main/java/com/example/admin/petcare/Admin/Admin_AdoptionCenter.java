package com.example.admin.petcare.Admin;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Admin_AdoptionCenter extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<AdminAdoptionCenterList> arrayList;
    AdminAdoptionCenterAdapter adapter;

    FloatingActionButton add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin__adoption_center);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Adoption Center");
        recyclerView = findViewById(R.id.admin_adoption_center_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(Admin_AdoptionCenter.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        add = findViewById(R.id.admin_adoption_center_fab1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Admin_AdoptionCenter.this, AddAdminAdoptionCenterActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new ConnectionDetector(Admin_AdoptionCenter.this).isConnectingToInternet()) {
            new getAdoptionCenterData().execute();
        } else {
            new ConnectionDetector(Admin_AdoptionCenter.this).connectiondetect();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class getAdoptionCenterData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Admin_AdoptionCenter.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getAdoptionCenter.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(s);
                if (jsonObject.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = jsonObject.getJSONArray("response");
                    arrayList = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        AdminAdoptionCenterList list = new AdminAdoptionCenterList();
                        list.setId(object.getString("id"));
                        list.setName(object.getString("a_name"));
                        list.setEmail(object.getString("a_email"));
                        list.setContact(object.getString("a_contact"));
                        list.setAddress(object.getString("a_address"));
                        list.setImage(object.getString("a_image"));
                        list.setCreatedDate(object.getString("created_date"));
                        arrayList.add(list);
                    }
                    adapter = new AdminAdoptionCenterAdapter(Admin_AdoptionCenter.this, arrayList);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(Admin_AdoptionCenter.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {

            }
        }
    }

    private class AdminAdoptionCenterAdapter extends RecyclerView.Adapter<AdminAdoptionCenterAdapter.MyHolder> {

        Context context;
        ArrayList<AdminAdoptionCenterList> arrayList;
        int iPosition;
        String sId;

        AdminAdoptionCenterAdapter(Context context, ArrayList<AdminAdoptionCenterList> arrayList) {
            this.context = context;
            this.arrayList = arrayList;
        }

        @NonNull
        @Override
        public AdminAdoptionCenterAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_admin_adoption_center, parent, false);
            return new AdminAdoptionCenterAdapter.MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull AdminAdoptionCenterAdapter.MyHolder holder, final int position) {
            holder.name.setText(arrayList.get(position).getName());
            holder.email.setText(arrayList.get(position).getEmail());
            holder.contact.setText(arrayList.get(position).getContact());
            holder.address.setText(arrayList.get(position).getAddress());
            holder.date.setText(arrayList.get(position).getCreatedDate());

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sId = arrayList.get(position).getId();
                        iPosition = position;
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteAdoptionCenter.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    if (jsonObject.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                        arrayList.remove(iPosition);
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {

                }
            }
        }

        private class MyHolder extends RecyclerView.ViewHolder {

            TextView name, email, contact, address, date;
            ImageView delete;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.custom_admin_adoption_center_name);
                email = itemView.findViewById(R.id.custom_admin_adoption_center_email);
                contact = itemView.findViewById(R.id.custom_admin_adoption_center_contact);
                address = itemView.findViewById(R.id.custom_admin_adoption_center_address);
                delete = itemView.findViewById(R.id.custom_admin_adoption_center_delete);
                date = itemView.findViewById(R.id.custom_admin_adoption_center_date);
            }
        }
    }
}
