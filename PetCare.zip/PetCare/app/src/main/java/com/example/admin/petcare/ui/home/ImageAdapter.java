package com.example.admin.petcare.ui.home;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


class ImageAdapter extends PagerAdapter {
    Context context;
    ArrayList<String> img;

    LayoutInflater mLayoutInflater;

    public ImageAdapter(FragmentActivity context1, ArrayList<String> img) {
        this.context = context1;
        this.img = img;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return img.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {

        return view == o;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View itemView = mLayoutInflater.inflate(R.layout.pager_item, container, false);

        ImageView imageView = (ImageView) itemView.findViewById(R.id.imageView);
        //imageView.setImageResource(img[position]);
        Picasso.with(context).load(ConstantSp.IMAGEURL+img.get(position)).placeholder(R.drawable.f).into(imageView);
        container.addView(itemView);

        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

}
