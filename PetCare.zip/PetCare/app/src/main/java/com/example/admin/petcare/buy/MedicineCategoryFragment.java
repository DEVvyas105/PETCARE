package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

public class MedicineCategoryFragment extends Fragment {

    RecyclerView gridView;
    ArrayList<CategoryList> categoryLists;
    CategoryAdapter adapter;

    /*String[] discription = {"1","2","3"};
    String[] power = {"11","22","33"};
    String[] price = {"aa","bb","cc"};*/

    String[] categoryName = {"Syrup","Capsule","Drops"};
    int[] image = {R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher};
    SharedPreferences sp;
    FloatingActionButton add;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_medicine_category, container, false);

        sp = getActivity().getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);
        add = root.findViewById(R.id.medicine_category_add);

       //getActivity().setTitle("Medicine Category");

        if(sp.getString(ConstantSp.USERTYPE,"").equals("Admin")){
            add.setVisibility(View.VISIBLE);
        }
        else{
            add.setVisibility(View.GONE);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.CATEGORY_ADD_UPDATE, "Add").commit();
                startActivity(new Intent(getActivity(),AddCategoryActivity.class));
            }
        });

        gridView = root.findViewById(R.id.medicine_cat_gv);
        gridView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){
            new categoryData().execute();
        }
        else{
            new ConnectionDetector(getActivity()).connectiondetect();
        }


        return root;
    }


    private class categoryData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"category.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    categoryLists = new ArrayList<>();
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        CategoryList list = new CategoryList();
                        list.setName(jsonObject.getString("name"));
                        list.setId(jsonObject.getString("id"));
                        list.setImage(jsonObject.getString("image"));
                        categoryLists.add(list);
                    }
                    adapter = new CategoryAdapter(getActivity(),categoryLists);
                    gridView.setAdapter(adapter);
                }

                else{
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
