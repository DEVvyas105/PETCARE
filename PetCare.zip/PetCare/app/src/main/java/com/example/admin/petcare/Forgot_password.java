package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Forgot_password extends AppCompatActivity {
    ImageButton back;

    EditText e1, e2, e3;
    Button b1;
    SharedPreferences sp;
    String email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().hide();

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        e1 = findViewById(R.id.forgot_cp_current);

        e2 = findViewById(R.id.forgot_cp_newpass);
        e3 = findViewById(R.id.forgot_cp_reeneterpass);
        b1 = findViewById(R.id.forgot_cp_button);

        back = findViewById(R.id.forgot_cp_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (e1.getText().toString().equalsIgnoreCase("")) {
                    e1.setError("Please enter email-id");
                } else if (!e1.getText().toString().matches(email_pattern)) {
                    e1.setError("Valid Email Id Required");
                    //Toast.makeText(SignupActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                } else if (e2.getText().toString().trim().equalsIgnoreCase("")) {
                    e2.setError("New Password Required");
                } else if (e3.getText().toString().trim().equalsIgnoreCase("")) {
                    e3.setError("Confirm Password Required");
                } else if (!e2.getText().toString().matches(e3.getText().toString())) {
                    e3.setError("Password Not Match");
                } else {
                    if (new ConnectionDetector(Forgot_password.this).isConnectingToInternet()) {
                        new forgotPass().execute();
                    } else {
                        new ConnectionDetector(Forgot_password.this).connectiondetect();
                    }
                }
            }
        });

    }

    private class forgotPass extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Forgot_password.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("email", e1.getText().toString());
            hashMap.put("password", e2.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "forgotPassword.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(s);
                if (jsonObject.getString("Status").equals("True")) {
                    Toast.makeText(Forgot_password.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                    onBackPressed();
                } else {
                    Toast.makeText(Forgot_password.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
