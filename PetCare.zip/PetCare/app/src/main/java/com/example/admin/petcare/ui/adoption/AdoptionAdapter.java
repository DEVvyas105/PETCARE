package com.example.admin.petcare.ui.adoption;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.admin.petcare.AdoptActivity;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

class AdoptionAdapter extends BaseAdapter {

    Context context;
    ArrayList<AllAdoption> allAdoptions;
    SharedPreferences sp;

    public AdoptionAdapter(Context activity, ArrayList<AllAdoption> allAdoption) {
        this.context=activity;
        this.allAdoptions=allAdoption;
        sp=context.getSharedPreferences(ConstantSp.PREF,Context.MODE_PRIVATE);

    }

    @Override
    public int getCount() {
        return allAdoptions.size();
    }

    @Override
    public Object getItem(int position) {
        return allAdoptions.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int i, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.custom_adoption,null);
        ImageView iv = view.findViewById(R.id.custom_chat_iv);
        TextView name = view.findViewById(R.id.custom_chat_name);
        TextView address =view.findViewById(R.id.custom_chat_address);
        TextView contact = view.findViewById(R.id.custom_chat_contact);

        name.setText(allAdoptions.get(i).getName());
        Picasso.with(context).load(ConstantSp.IMAGEURL + allAdoptions.get(i).getImage()).placeholder(R.drawable.logo).into(iv);
        contact.setText(allAdoptions.get(i).getContact());
        address.setText(allAdoptions.get(i).getAddress());
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)

            {
                sp.edit().putString(ConstantSp.ADOPTIONId,allAdoptions.get(i).getId()).commit();
                Intent intent;
                intent = new Intent(context, AdoptActivity.class);
                context.startActivity(intent);
            }
        });


        return view;
    }
}


