package com.example.admin.petcare.Admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.Admin.AllPaidPets;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;

import java.util.ArrayList;

class AdminCustomPaidAdapter extends RecyclerView.Adapter<AdminCustomPaidAdapter.MyHolder> {

    Context context;
    ArrayList<AllPaidPets> allPaidPets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public AdminCustomPaidAdapter(Context context, ArrayList<AllPaidPets> allPaidPets) {
        this.context = context;
        this.allPaidPets = allPaidPets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public AdminCustomPaidAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.admin_pet_paid_grid, parent, false);
        return new AdminCustomPaidAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdminCustomPaidAdapter.MyHolder holder, final int position) {
        holder.petName.setText(allPaidPets.get(position).getPetname() + " ( " + context.getResources().getString(R.string.rs_symbol) + allPaidPets.get(position).getPrice() + " )");
        holder.height.setText(allPaidPets.get(position).getHeight() + " Inch");
        holder.weight.setText(allPaidPets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allPaidPets.get(position).getLifespan() + " Year");
        holder.name.setText(allPaidPets.get(position).getName());
        holder.email.setText(allPaidPets.get(position).getEmail());
        holder.contact.setText(allPaidPets.get(position).getContactNo());
    }

    @Override
    public int getItemCount() {
        return allPaidPets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.admin_pet_paid_grid_petname);
            height = itemView.findViewById(R.id.admin_pet_paid_grid_height);
            weight = itemView.findViewById(R.id.admin_pet_paid_grid_wight);
            lifespan = itemView.findViewById(R.id.admin_pet_paid_grid_lifespan);
            name = itemView.findViewById(R.id.admin_pet_paid_grid_name);
            email = itemView.findViewById(R.id.admin_pet_paid_grid_email);
            contact = itemView.findViewById(R.id.admin_pet_paid_grid_contact);
        }
    }
}
