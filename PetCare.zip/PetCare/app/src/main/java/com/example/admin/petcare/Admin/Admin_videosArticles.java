package com.example.admin.petcare.Admin;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.example.admin.petcare.UserActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Admin_videosArticles extends AppCompatActivity {

    EditText e1,e2;
    Button add;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_videos_articles);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        e1=findViewById(R.id.admin_articleTitle);
        e2=findViewById(R.id.admin_articleContent);
        add=findViewById(R.id.admin_articlebtn);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (new ConnectionDetector(Admin_videosArticles.this).isConnectingToInternet()) {
                    new insertdata().execute();

                } else {
                    new ConnectionDetector(Admin_videosArticles.this).connectiondetect();
                }
            }
        });


    }
    public class insertdata extends AsyncTask<String,String ,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Admin_videosArticles.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")

        @Override
        protected String doInBackground(String... strings) {

            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("a_title",e1.getText().toString());
            hashMap.put("a_content",e2.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"addArticles.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    Toast.makeText(Admin_videosArticles.this,object.getString("Message"),Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Admin_videosArticles.this, UserActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText( Admin_videosArticles.this,object.getString("Message"),Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
