package com.example.admin.petcare.buy;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductActivity extends AppCompatActivity {

    SharedPreferences sp;
    RecyclerView gridView;
    ArrayList<ProductList> productLists;
    ProductAdapter adapter;


    String[] categoryName = {"Mucovib", "Zincovit", "Drops"};
    int[] image = {R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher};
    String[] discription = {"cough syrup", "Vitamin B12 deficiency,Anaemia", "3"};
    String[] power = {"100ml", "200ml", "33"};
    String[] price = {"Rs.37.42", "Rs.119", "cc"};

    FloatingActionButton add;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        getSupportActionBar().setTitle("Products");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        add = findViewById(R.id.product_add);

        if (sp.getString(ConstantSp.USERTYPE, "").equals("Admin")) {
            add.setVisibility(View.VISIBLE);
        } else {
            add.setVisibility(View.GONE);
        }

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCT_ADD_UPDATE, "Add").commit();
                startActivity(new Intent(ProductActivity.this, AddProductActivity.class));
            }
        });


        gridView = findViewById(R.id.medicine_prod_gv);
        gridView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));

        if (new ConnectionDetector(ProductActivity.this).isConnectingToInternet()) {
            new productData().execute();
        } else {
            new ConnectionDetector(ProductActivity.this).connectiondetect();
        }

    }

    private class productData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ProductActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            if (sp.getString(ConstantSp.CATEGORYID, "").equals("")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("search", sp.getString(ConstantSp.SEARCH, ""));
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "searchcategory.php", MakeServiceCall.POST, hashMap);
            } else {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("category_id", sp.getString(ConstantSp.CATEGORYID, ""));
                hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "subcategory.php", MakeServiceCall.POST, hashMap);
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();

            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    productLists = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        ProductList list = new ProductList();
                        list.setId(jsonObject.getString("id"));
                        list.setName(jsonObject.getString("name"));
                        list.setDiscription(jsonObject.getString("discription"));
                        list.setQuantity(jsonObject.getString("quantity"));
                        list.setPrice(jsonObject.getString("price"));
                        list.setImage(jsonObject.getString("image"));
                        productLists.add(list);
                    }
                    adapter = new ProductAdapter(ProductActivity.this, productLists);
                    gridView.setAdapter(adapter);
                } else {
                    Toast.makeText(ProductActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        MenuItem searchViewItem = menu.findItem(R.id.menu_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchViewItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchView.clearFocus();
                sp.edit().putString(ConstantSp.PRODUCTID, "").commit();
                sp.edit().putString(ConstantSp.SEARCH, s).commit();
                startActivity(new Intent(ProductActivity.this, ShowActivity.class));
                return false;

            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        if (id == R.id.menu_cart) {
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.nav_host_fragment_dashboard, new AddcartFragment()).commit();
        }
        /*if (id == R.id.menu_wishlist){
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.nav_host_fragment,new WishlistFragment()).commit();
        }*/
        return super.onOptionsItemSelected(item);
    }
}
