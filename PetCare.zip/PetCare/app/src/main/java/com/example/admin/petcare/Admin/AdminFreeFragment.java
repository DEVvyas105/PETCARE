package com.example.admin.petcare.Admin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.Admin.AllFreePets;
import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.Admin.CustomAdminFreeAdapter;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AdminFreeFragment extends Fragment {

    SharedPreferences sp;
    RecyclerView freeGrid;
    ArrayList<AllFreePets> allFreePets;

    public AdminFreeFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.admin_free_layout, container, false);

        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

        // Inflate the layout for this fragment
        freeGrid = root.findViewById(R.id.admin_free_grid);
        freeGrid.setLayoutManager(new LinearLayoutManager(getActivity()));
        freeGrid.setItemAnimator(new DefaultItemAnimator());

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getFreeUserData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
        return root;
    }


    private class getFreeUserData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            hashMap.put("u_type", "Free");
            hashMap.put("isPurchase", "2");
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getAdoptionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    allFreePets = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllFreePets list = new AllFreePets();
                        list.setId(jsonObject.getString("id"));
                        list.setUserId(jsonObject.getString("userId"));
                        list.setName(jsonObject.getString("u_name"));
                        list.setEmail(jsonObject.getString("u_email"));
                        list.setContactNo(jsonObject.getString("u_cno"));
                        list.setHeight(jsonObject.getString("u_height"));
                        list.setWeight(jsonObject.getString("u_weight"));
                        list.setLifespan(jsonObject.getString("u_lifespan"));
                        list.setPetname(jsonObject.getString("u_petname"));
                        list.setPrice(jsonObject.getString("u_prize"));
                        list.setFromDate(jsonObject.getString("u_from"));
                        list.setToDate(jsonObject.getString("u_to"));
                        allFreePets.add(list);

                    }
                    CustomAdminFreeAdapter adapter = new CustomAdminFreeAdapter(getActivity(), allFreePets);
                    freeGrid.setAdapter(adapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
