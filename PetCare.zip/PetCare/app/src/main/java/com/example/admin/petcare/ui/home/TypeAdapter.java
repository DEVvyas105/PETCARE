package com.example.admin.petcare.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.petcare.AllPetsList;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.DetailsAboutPet;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class TypeAdapter extends BaseAdapter {

    Context context;
    ArrayList<AllPetsList> allPetsLists;
    SharedPreferences sp;

    public TypeAdapter(Context activity, ArrayList<AllPetsList> allPetsLists) {
        this.context = activity;
        this.allPetsLists = allPetsLists;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @Override
    public int getCount() {
        return allPetsLists.size();
    }

    @Override
    public Object getItem(int position) {
        return allPetsLists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int i, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.pet_list, null);
        ImageView iv = view.findViewById(R.id.pet_img);
        TextView name = view.findViewById(R.id.pet_name);

        name.setText(allPetsLists.get(i).getName());
        Picasso.with(context).load(ConstantSp.IMAGEURL + allPetsLists.get(i).getImage()).placeholder(R.drawable.logo).into(iv);
        //iv.setImageResource(img[i]);

        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putString(ConstantSp.PRODUCTId, allPetsLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.PETNAME, allPetsLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.PETIMAGE, allPetsLists.get(i).getImage()).commit();
                sp.edit().putString(ConstantSp.PETHEIGHT, allPetsLists.get(i).getHeight()).commit();
                sp.edit().putString(ConstantSp.PETWEIGHT, allPetsLists.get(i).getWeight()).commit();
                sp.edit().putString(ConstantSp.PETLIFESPAN, allPetsLists.get(i).getLifespan()).commit();
                sp.edit().putString(ConstantSp.PETPERSONALITY, allPetsLists.get(i).getPersonality()).commit();
                sp.edit().putString(ConstantSp.PETHISTORY, allPetsLists.get(i).getHistory()).commit();
                sp.edit().putString(ConstantSp.PETDIET, allPetsLists.get(i).getDiet()).commit();
                Intent intent = new Intent(context, DetailsAboutPet.class);
                context.startActivity(intent);
            }
        });

        return view;
    }
}
