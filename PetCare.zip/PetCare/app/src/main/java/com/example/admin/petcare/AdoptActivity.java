package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.petcare.ui.adoption.CustmAdapter;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class AdoptActivity extends AppCompatActivity {

    ListView pets;
    ImageView iv;
    TextView name,address;
    ImageButton back;
    String[] pets_array= {"Gername Shepherd","Abasican Cat","Indian Dogs","African Parrtot","Chipooo Monkey"};
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adopt);
        getSupportActionBar().hide();

        sp=getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);

        back = findViewById(R.id.back);
        pets=findViewById(R.id.pet);
        iv = findViewById(R.id.img1);
        name = findViewById(R.id.a_name);
        address = findViewById(R.id.address);

        final CustmAdapter adapter=new CustmAdapter(AdoptActivity.this,pets_array);
        pets.setAdapter(adapter);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        pets.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // TODO Auto-generated method stub
                //String value= (String) adapter.getItem(position);
                //Toast.makeText(getApplicationContext(),value, Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(AdoptActivity.this,PetDetailsActivity.class);
                startActivity(intent);
            }
        });

        if(new ConnectionDetector(AdoptActivity.this).isConnectingToInternet()){
            new getData().execute();
        }
        else{
            new ConnectionDetector(AdoptActivity.this).connectiondetect();
        }
    }


    class getData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AdoptActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getAdoptionDetails.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        Picasso.with(AdoptActivity.this).load(ConstantSp.IMAGEURL + jsonObject.getString("a_image")).placeholder(R.drawable.logo).into(iv);
                        name.setText(jsonObject.getString("a_name"));
                        address.setText(jsonObject.getString("a_address"));
                    }
                }
                else{
                    Toast.makeText(AdoptActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

