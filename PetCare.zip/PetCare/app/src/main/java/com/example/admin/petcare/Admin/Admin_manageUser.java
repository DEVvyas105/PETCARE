package com.example.admin.petcare.Admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Admin_manageUser extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<UserList> arrayList;
    UserListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manage_user);
        getSupportActionBar().setTitle("Manage User");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recyclerView = findViewById(R.id.admin_manage_user_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(Admin_manageUser.this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        if (new ConnectionDetector(Admin_manageUser.this).isConnectingToInternet()) {
            new getUserData().execute();
        } else {
            new ConnectionDetector(Admin_manageUser.this).connectiondetect();
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class getUserData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Admin_manageUser.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("type", "User");
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getUser.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject jsonObject = new JSONObject(s);
                if (jsonObject.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = jsonObject.getJSONArray("response");
                    arrayList = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object = array.getJSONObject(i);
                        UserList list = new UserList();
                        list.setId(object.getString("id"));
                        list.setName(object.getString("name"));
                        list.setEmail(object.getString("email"));
                        list.setContact(object.getString("contact"));
                        list.setAddress(object.getString("address"));
                        list.setPincode(object.getString("pincode"));
                        list.setCity(object.getString("city"));
                        list.setState(object.getString("state"));
                        list.setCreatedDate(object.getString("created_date"));
                        arrayList.add(list);
                    }
                    adapter = new UserListAdapter(Admin_manageUser.this, arrayList);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(Admin_manageUser.this, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {

            }
        }
    }

    private class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.MyHolder> {

        Context context;
        ArrayList<UserList> arrayList;
        int iPosition;
        String sId;

        UserListAdapter(Context context, ArrayList<UserList> arrayList) {
            this.context = context;
            this.arrayList = arrayList;
        }

        @NonNull
        @Override
        public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_user, parent, false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
            holder.name.setText(arrayList.get(position).getName());
            holder.email.setText(arrayList.get(position).getEmail());
            holder.contact.setText(arrayList.get(position).getContact());
            holder.address.setText(arrayList.get(position).getAddress() + " , " + arrayList.get(position).getCity() + " , " + arrayList.get(position).getState() + " , " + arrayList.get(position).getPincode());
            holder.date.setText(arrayList.get(position).getCreatedDate());

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sId = arrayList.get(position).getId();
                        iPosition = position;
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return arrayList.size();
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteUser.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    if (jsonObject.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                        arrayList.remove(iPosition);
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(context, jsonObject.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {

                }
            }
        }

        private class MyHolder extends RecyclerView.ViewHolder {

            TextView name, email, contact, address, date;
            ImageView delete;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.custom_user_name);
                email = itemView.findViewById(R.id.custom_user_email);
                contact = itemView.findViewById(R.id.custom_user_contact);
                address = itemView.findViewById(R.id.custom_user_address);
                delete = itemView.findViewById(R.id.custom_user_delete);
                date = itemView.findViewById(R.id.custom_user_date);
            }
        }
    }
}
