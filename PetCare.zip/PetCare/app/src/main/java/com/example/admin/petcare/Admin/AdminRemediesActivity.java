package com.example.admin.petcare.Admin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.admin.petcare.AllRemedyDetails;
import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.example.admin.petcare.ui.home.RemedyModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AdminRemediesActivity extends AppCompatActivity {

    private RecyclerView remediesrecycler;
    private ArrayList<RemedyModel> imageModelArrayList1;
    AdminRemedyAdapter remedyAdapter;

    FloatingActionButton add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_remedies);
        getSupportActionBar().setTitle("Manage Home Remedies");
        add = findViewById(R.id.admin_hr_fab1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AdminRemediesActivity.this, AddAdminRemediesActivity.class));
            }
        });

        remediesrecycler = (RecyclerView) findViewById(R.id.admin_hr_recycler);
        remediesrecycler.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
        remediesrecycler.setItemAnimator(new DefaultItemAnimator());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (new ConnectionDetector(AdminRemediesActivity.this).isConnectingToInternet()) {
            new getRemedyData().execute();
        } else {
            new ConnectionDetector(AdminRemediesActivity.this).connectiondetect();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class getRemedyData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AdminRemediesActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("typeId",sp.getString(ConstantSp.TYPEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getRemedy.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    imageModelArrayList1 = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        RemedyModel remedyModel = new RemedyModel();
                        remedyModel.setId(jsonObject.getString("id"));
                        remedyModel.setName(jsonObject.getString("title"));
                        remedyModel.setImage(jsonObject.getString("image"));
                        remedyModel.setContent(jsonObject.getString("content"));
                        imageModelArrayList1.add(remedyModel);
                    }
                    remedyAdapter = new AdminRemedyAdapter(AdminRemediesActivity.this, imageModelArrayList1);
                    remediesrecycler.setAdapter(remedyAdapter);

                } else {
                    Toast.makeText(AdminRemediesActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public class AdminRemedyAdapter extends RecyclerView.Adapter<AdminRemedyAdapter.MyViewHolder> {

        public LayoutInflater inflater;
        Context context;
        private ArrayList<RemedyModel> imageModelArrayList1;
        SharedPreferences sp;

        int iPosition;
        String sId;

        public AdminRemedyAdapter(Context context, ArrayList<RemedyModel> imageModelArrayList1) {
            inflater = LayoutInflater.from(context);
            this.imageModelArrayList1 = imageModelArrayList1;
            this.context = context;
            sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

        }

        @NonNull
        @Override
        public AdminRemedyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
            View view = inflater.inflate(R.layout.admin_remedy_item, parent, false);
            AdminRemedyAdapter.MyViewHolder holder = new AdminRemedyAdapter.MyViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(@NonNull AdminRemedyAdapter.MyViewHolder holder, final int position) {
            Picasso.with(context).load(ConstantSp.IMAGEURL + imageModelArrayList1.get(position).getImage()).placeholder(R.drawable.logo).into(holder.iv);
            //holder.iv.setImageResource(imageModelArrayList1.get(position).getImage());
            holder.time.setText(imageModelArrayList1.get(position).getName());

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sId = imageModelArrayList1.get(position).getId();
                        iPosition = position;
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });

            holder.iv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    sp.edit().putString(ConstantSp.REMEDYId, imageModelArrayList1.get(position).getId()).commit();
                    sp.edit().putString(ConstantSp.REMEDYNAME, imageModelArrayList1.get(position).getName()).commit();
                    sp.edit().putString(ConstantSp.REMEDYIMAGE, imageModelArrayList1.get(position).getImage()).commit();
                    sp.edit().putString(ConstantSp.REMEDYCONTENT, imageModelArrayList1.get(position).getContent()).commit();
                    Intent intent = new Intent(context, AllRemedyDetails.class);
                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return imageModelArrayList1.size();
        }

        class MyViewHolder extends RecyclerView.ViewHolder {


            RemedyModel remedyModel = new RemedyModel();

            TextView time;
            ImageView iv, delete;

            public MyViewHolder(View itemView) {
                super(itemView);
                time = (TextView) itemView.findViewById(R.id.admin_remedy_name);
                iv = (ImageView) itemView.findViewById(R.id.admin_remedy_img);
                delete = itemView.findViewById(R.id.admin_remedy_delete);
            }
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteRemedies.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                        imageModelArrayList1.remove(iPosition);
                        remedyAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}