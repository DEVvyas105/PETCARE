package com.example.admin.petcare.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class AddArticlesActivity extends AppCompatActivity {

    Button add;
    EditText article, content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_articles);
        getSupportActionBar().setTitle("Add Article");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        add = findViewById(R.id.add_admin_articles_add);
        article = findViewById(R.id.add_admin_articles_title);
        content = findViewById(R.id.add_admin_articles_content);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (article.getText().toString().trim().equalsIgnoreCase("")) {
                    article.setError("Article Title Required");
                } else if (content.getText().toString().trim().equalsIgnoreCase("")) {
                    content.setError("Article Content Required");
                } else {
                    if (new ConnectionDetector(AddArticlesActivity.this).isConnectingToInternet()) {
                        new insertArticledata().execute();
                    } else {
                        new ConnectionDetector(AddArticlesActivity.this).connectiondetect();
                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class insertArticledata extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AddArticlesActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("a_title", article.getText().toString());
            hashMap.put("a_content", content.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addArticle.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(AddArticlesActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    onBackPressed();
                } else {
                    Toast.makeText(AddArticlesActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}