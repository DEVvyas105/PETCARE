package com.example.admin.petcare;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class GuidelineAdapter extends BaseAdapter {

    Context context;
    String[] g_array;

    public GuidelineAdapter(Context context, String[] guide_array) {
        this.context=context;
        this.g_array=guide_array;
    }


    @Override
    public int getCount() {
        return g_array.length;
    }

    @Override
    public Object getItem(int position) {
        return g_array[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.guidelist_layout,null);

        TextView name = view.findViewById(R.id.guide_text);

        name.setText(g_array[position]);

        return view;
    }
}
