package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

class OwnPetsAdapter extends RecyclerView.Adapter<OwnPetsAdapter.MyHolder> {

    Context context;
    ArrayList<OwnPetsList> allFreePets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public OwnPetsAdapter(Context context, ArrayList<OwnPetsList> allFreePets) {
        this.context = context;
        this.allFreePets = allFreePets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_own_pets, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        if (allFreePets.get(position).getPrice().equalsIgnoreCase("")) {
            holder.petName.setText(allFreePets.get(position).getPetname());
        } else {
            holder.petName.setText(allFreePets.get(position).getPetname() + " ( " + context.getResources().getString(R.string.rs_symbol) + allFreePets.get(position).getPrice() + " )");
        }

        if (allFreePets.get(position).getFromDate().equalsIgnoreCase("") && allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
            holder.dateLayout.setVisibility(View.GONE);
        } else {
            holder.dateLayout.setVisibility(View.VISIBLE);
            if (allFreePets.get(position).getFromDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getToDate());
            } else if (allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getFromDate());
            } else {
                holder.date.setText(allFreePets.get(position).getFromDate() + " To " + allFreePets.get(position).getToDate());
            }
        }

        if (allFreePets.get(position).getType().equalsIgnoreCase("Free")) {
            holder.sendMoney.setVisibility(View.GONE);
        } else {
            if (allFreePets.get(position).getAdoptUserId().equalsIgnoreCase("") && (allFreePets.get(position).getTransactionId() == null|| allFreePets.get(position).getTransactionId().equalsIgnoreCase("null") || allFreePets.get(position).getTransactionId().equalsIgnoreCase(""))) {
                holder.sendMoney.setVisibility(View.GONE);
            } else {
                if (allFreePets.get(position).getTransactionId() == null || allFreePets.get(position).getTransactionId().equalsIgnoreCase("null") || allFreePets.get(position).getTransactionId().equalsIgnoreCase("")) {
                    holder.sendMoney.setVisibility(View.VISIBLE);
                } else {
                    holder.sendMoney.setVisibility(View.GONE);
                }
            }
        }

        if(allFreePets.get(position).getAdopted_username().equalsIgnoreCase("")){
            holder.adoptedUsernameLayout.setVisibility(View.GONE);
        }
        else{
            holder.adoptedUsernameLayout.setVisibility(View.VISIBLE);
            holder.adoptedName.setText(allFreePets.get(position).getAdopted_username());
        }

        holder.height.setText(allFreePets.get(position).getHeight() + " Inch");
        holder.weight.setText(allFreePets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allFreePets.get(position).getLifespan() + " Year");
        holder.name.setText(allFreePets.get(position).getName());
        holder.email.setText(allFreePets.get(position).getEmail());
        holder.contact.setText(allFreePets.get(position).getContactNo());

        holder.sendMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.ADOPTID, allFreePets.get(position).getId()).commit();
                sp.edit().putString(ConstantSp.ADOPTUSERID, allFreePets.get(position).getAdoptUserId()).commit();
                sp.edit().putString(ConstantSp.ADOPTUSERNAME, allFreePets.get(position).getAdopted_username()).commit();
                sp.edit().putString(ConstantSp.ADOPTPOSITION, String.valueOf(position)).commit();
                sp.edit().putString(ConstantSp.ADOPTPRICE, allFreePets.get(position).getPrice()).commit();
                sp.edit().putString(ConstantSp.ADOPTPETNAME, allFreePets.get(position).getPetname()).commit();
                context.startActivity(new Intent(context, AddPaymentActivity.class));
            }
        });

    }

    @Override
    public int getItemCount() {
        return allFreePets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact, date,adoptedName;
        LinearLayout dateLayout,adoptedUsernameLayout;
        Button sendMoney;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.custom_own_pets_petname);
            height = itemView.findViewById(R.id.custom_own_pets_height);
            weight = itemView.findViewById(R.id.custom_own_pets_wight);
            lifespan = itemView.findViewById(R.id.custom_own_pets_lifespan);
            name = itemView.findViewById(R.id.custom_own_pets_name);
            email = itemView.findViewById(R.id.custom_own_pets_email);
            contact = itemView.findViewById(R.id.custom_own_pets_contact);
            date = itemView.findViewById(R.id.custom_own_pets_date);
            dateLayout = itemView.findViewById(R.id.custom_own_pets_date_layout);
            sendMoney = itemView.findViewById(R.id.custom_own_pets_send);
            adoptedUsernameLayout = itemView.findViewById(R.id.custom_own_pets_adopted_username_layout);
            adoptedName = itemView.findViewById(R.id.custom_own_pets_adopted_username);
        }
    }
}
