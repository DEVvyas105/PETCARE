package com.example.admin.petcare.ui.home;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.Guidelines;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class HomeFragment extends Fragment {

    ViewPager viewPager;
    ArrayList<String> bannerList;
    //int img[] = {R.drawable.cockatiel,R.drawable.fish, R.drawable.dalmatian, R.drawable.leonberger, R.drawable.canary};

    LinearLayout sliderDotspanel;
    private int dotscount;
    private ImageView[] dots;

    ImageButton view;

    private RecyclerView recyclerView;
    private ArrayList<CategoryModel> imageModelArrayList;
    private CategoryAdapter categoryAdapter;
    /*private int[] myImageList = new int[]{R.drawable.bird, R.drawable.cat, R.drawable.dog, R.drawable.fish, R.drawable.goat, R.drawable.monkey, R.drawable.rat,R.drawable.rabbit,R.drawable.tortoise};
    private String[] myImageNameList = new String[]{"Bird", "Cat", "Dog", "Fish", "Goat", "Monkey", "Rat","Rabbits","Tortoise"};
    String[] myImageId = {"1", "2", "3", "4", "5", "6", "7","8","9"};*/


    private RecyclerView remediesrecycler;
    private ArrayList<RemedyModel> imageModelArrayList1;
    private RemedyAdapter remedyAdapter;
    private int[] myImageList1 = new int[]{R.drawable.remedy1, R.drawable.remedy1};
    private String[] myImageNameList1 = new String[]{"Home Remedy 1 ", "Home Remedy 2"};

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();

        viewPager = root.findViewById(R.id.pager);

        view = root.findViewById(R.id.ib);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Guidelines.class);
                startActivity(intent);
            }
        });

        sliderDotspanel = (LinearLayout) root.findViewById(R.id.SliderDots);

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                for (int i = 0; i < dotscount; i++) {
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.non_active));
                }

                dots[position].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.active_dot));

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        //type of pets

        recyclerView = (RecyclerView) root.findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        //home remedies

        remediesrecycler = (RecyclerView) root.findViewById(R.id.hr_recycler);
        remediesrecycler.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        imageModelArrayList1 = new ArrayList<>();

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getBannerData().execute();
            new getPetTypeData().execute();
            new getRemedyData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }


        return root;
    }

    private class getBannerData extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("typeId",sp.getString(ConstantSp.TYPEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getBanner.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    bannerList = new ArrayList<>();
                    dotscount = array.length();
                    dots = new ImageView[dotscount];
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        bannerList.add(jsonObject.getString("image"));
                        dots[i] = new ImageView(getActivity());
                        dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.non_active));
                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                        params.setMargins(8, 1, 8, 1);
                        sliderDotspanel.addView(dots[i], params);
                    }

                    ImageAdapter adapter = new ImageAdapter(getActivity(), bannerList);
                    viewPager.setAdapter(adapter);
                    dots[0].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.active_dot));
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class getPetTypeData extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("typeId",sp.getString(ConstantSp.TYPEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getPetType.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    imageModelArrayList = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        CategoryModel categoryModel = new CategoryModel();
                        categoryModel.setId(jsonObject.getString("id"));
                        categoryModel.setName(jsonObject.getString("type"));
                        categoryModel.setImage_drawable(jsonObject.getString("image"));
                        imageModelArrayList.add(categoryModel);
                    }
                    categoryAdapter = new CategoryAdapter(getContext(), imageModelArrayList);
                    recyclerView.setAdapter(categoryAdapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class getRemedyData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("typeId",sp.getString(ConstantSp.TYPEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getRemedy.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    imageModelArrayList1 = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        RemedyModel remedyModel = new RemedyModel();
                        remedyModel.setId(jsonObject.getString("id"));
                        remedyModel.setName(jsonObject.getString("title"));
                        remedyModel.setImage(jsonObject.getString("image"));
                        remedyModel.setContent(jsonObject.getString("content"));
                        imageModelArrayList1.add(remedyModel);
                    }
                    remedyAdapter = new RemedyAdapter(getContext(), imageModelArrayList1);
                    remediesrecycler.setAdapter((RecyclerView.Adapter) remedyAdapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
