package com.example.admin.petcare.Admin;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.example.admin.petcare.ui.Video.AllArticles;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

public class AdminArticleFragment extends Fragment {

    RecyclerView article_list;
    SharedPreferences sp;
    ArrayList<AllArticles> allArticles;

    FloatingActionButton add;
    AdminArticleAdapter articleAdapter;

    public AdminArticleFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.admin_article_layout, container, false);

        article_list = root.findViewById(R.id.admin_article_list);
        article_list.setLayoutManager(new LinearLayoutManager(getActivity()));
        article_list.setItemAnimator(new DefaultItemAnimator());
        sp = getActivity().getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        add = root.findViewById(R.id.admin_article_fab1);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AddArticlesActivity.class));
            }
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getArticle().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
    }

    private class getArticle extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getArticle.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    allArticles = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllArticles list = new AllArticles();
                        list.setId(jsonObject.getString("id"));
                        list.setTitle(jsonObject.getString("a_title"));
                        list.setContent(jsonObject.getString("a_content"));
                        list.setDate(jsonObject.getString("created_date"));
                        allArticles.add(list);

                    }
                    articleAdapter = new AdminArticleAdapter(getActivity(), allArticles);
                    article_list.setAdapter(articleAdapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    class AdminArticleAdapter extends RecyclerView.Adapter<AdminArticleAdapter.MyHolder> {

        Context context;
        ArrayList<AllArticles> allArticles;
        SharedPreferences sp;
        int iPosition;
        String sId;

        public AdminArticleAdapter(Context activity, ArrayList<AllArticles> allArticles) {
            this.context = activity;
            this.allArticles = allArticles;
            sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

        }

        @NonNull
        @Override
        public AdminArticleAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_admin_article, parent, false);
            return new AdminArticleAdapter.MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull AdminArticleAdapter.MyHolder holder, final int position) {
            holder.t1.setText(allArticles.get(position).getTitle());
            holder.t2.setText(allArticles.get(position).getContent());
            holder.date.setText(allArticles.get(position).getDate());

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sId = allArticles.get(position).getId();
                    iPosition = position;
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return allArticles.size();
        }

        public class MyHolder extends RecyclerView.ViewHolder {
            TextView t1, t2, date;
            ImageView delete;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                t1 = itemView.findViewById(R.id.admin_c_t1);
                t2 = itemView.findViewById(R.id.admin_c_t2);
                date = itemView.findViewById(R.id.admin_c_date);
                delete = itemView.findViewById(R.id.admin_c_delete);
            }
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteArticles.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equalsIgnoreCase("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                        allArticles.remove(iPosition);
                        articleAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
