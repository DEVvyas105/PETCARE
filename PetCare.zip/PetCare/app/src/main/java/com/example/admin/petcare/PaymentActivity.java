package com.example.admin.petcare;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {

    Button pay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        pay =findViewById(R.id.payment_pay);

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(PaymentActivity.this, "Adoption Sucessfull.....", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(PaymentActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}
