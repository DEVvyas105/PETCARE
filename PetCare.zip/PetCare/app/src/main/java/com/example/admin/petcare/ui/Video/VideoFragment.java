package com.example.admin.petcare.ui.Video;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.admin.petcare.R;

public class VideoFragment extends Fragment {

    TabLayout tabLayout;
    ViewPager viewPager;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();

        View root = inflater.inflate(R.layout.fragment_video, container, false);
        tabLayout = root.findViewById(R.id.tab_tablayout);
        viewPager = root.findViewById(R.id.tab_viewpager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        TabLayoutAdapter adapter = new TabLayoutAdapter(getActivity().getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        return root;
    }

    private class TabLayoutAdapter extends FragmentPagerAdapter {
        public TabLayoutAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);

        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int i) {
            switch (i) {
                case 0:
                    return "Videos";
                case 1:
                    return "Articles";
            }
            return null;
        }

        @Override
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return new VidFragment();
                case 1:
                    return new ArticleFragment();

            }
            return null;
        }

        @Override
        public int getCount() {
            return 2;
        }

    }
}


