package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AddcartFragment extends Fragment {

    RecyclerView gridView;
    ArrayList<CartList> cartLists;
    CartListAdapter adapter;

    Button checkout, continue_cart;

    String[] categoryName = {"Mucovib", "Zincovit", "Drops"};
    int[] image = {R.mipmap.ic_launcher, R.mipmap.ic_launcher, R.mipmap.ic_launcher};
    String[] price = {"Rs.37.42", "Rs.119", "cc"};
    //add quantity ........

    SharedPreferences sp;
    TextView total;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_addcart, container, false);

        checkout = root.findViewById(R.id.cart_checkout);
        continue_cart = root.findViewById(R.id.cart_continue);

        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        sp.edit().putString(ConstantSp.SELECTMETHOD, "Cart").commit();
        if (sp.getString(ConstantSp.USERTYPE, "").equals("Admin")) {
            checkout.setVisibility(View.GONE);
            continue_cart.setVisibility(View.GONE);
        } else {
            checkout.setVisibility(View.VISIBLE);//jump on Shipping Address.....
            continue_cart.setVisibility(View.VISIBLE);//jump on category fragment..
        }
        gridView = root.findViewById(R.id.add_to_cart_prod_gv);
        gridView.setLayoutManager(new LinearLayoutManager(getActivity()));
        gridView.setItemAnimator(new DefaultItemAnimator());
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new cartData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        continue_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTID, "");
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.cart_fragment, new MedicineCategoryFragment()).commit();
            }
        });
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), Upload_prescription.class));
            }
        });
        total = root.findViewById(R.id.addcart_total);
        return root;
    }

    private class cartData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "cartlist.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    sp.edit().putString(ConstantSp.TOTAL, object.getString("total")).commit();
                    total.setText("Total Amount : Rs." + object.getString("total"));
                    JSONArray array = object.getJSONArray("response");
                    cartLists = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        CartList list = new CartList();
                        list.setId(jsonObject.getString("id"));
                        list.setName(jsonObject.getString("name"));
                        list.setImage(jsonObject.getString("image"));
                        list.setQuantity(jsonObject.getString("quantity"));
                        list.setCartQty(jsonObject.getString("cart_quantity"));
                        list.setPrice(jsonObject.getString("price"));
                        list.setProduct_id(jsonObject.getString("product_id"));
                        cartLists.add(list);
                    }
                    adapter = new CartListAdapter(getActivity(), cartLists);
                    gridView.setAdapter(adapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class CartListAdapter extends RecyclerView.Adapter<CartListAdapter.MyHolder> {

        Context context;
        ArrayList<CartList> cartLists;
        LayoutInflater layoutInflater;
        SharedPreferences sp;
        String sCartId, sQty;
        String sProductId;

        public CartListAdapter(FragmentActivity addcartActivity, ArrayList<CartList> cartLists) {
            context = addcartActivity;
            this.cartLists = cartLists;
            layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        }

        @NonNull
        @Override
        public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.addtocart_category, viewGroup, false);
            return new MyHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyHolder holder, final int i) {
            Picasso.with(context).load(cartLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(holder.iv);
            holder.name.setText(cartLists.get(i).getName());
            holder.quantity.setText(cartLists.get(i).getQuantity());
            holder.cartQuantity.setText(cartLists.get(i).getCartQty());
            holder.price.setText("Rs. " + cartLists.get(i).getPrice());

            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sCartId = cartLists.get(i).getId();
                        new deleteData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });

            holder.wishlist.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sProductId = cartLists.get(i).getProduct_id();
                        new wishlistData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }

                }
            });

            holder.plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (new ConnectionDetector(context).isConnectingToInternet()) {
                        sCartId = cartLists.get(i).getId();
                        sQty = String.valueOf(Integer.parseInt(cartLists.get(i).getCartQty()) + 1);
                        new updateCartData().execute();
                    } else {
                        new ConnectionDetector(context).connectiondetect();
                    }
                }
            });

            holder.minus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (cartLists.get(i).getCartQty().equals("1")) {
                        if (new ConnectionDetector(context).isConnectingToInternet()) {
                            sCartId = cartLists.get(i).getId();
                            new deleteData().execute();
                        } else {
                            new ConnectionDetector(context).connectiondetect();
                        }
                    } else {
                        if (new ConnectionDetector(context).isConnectingToInternet()) {
                            sCartId = cartLists.get(i).getId();
                            sQty = String.valueOf(Integer.parseInt(cartLists.get(i).getCartQty()) - 1);
                            new updateCartData().execute();
                        } else {
                            new ConnectionDetector(context).connectiondetect();
                        }
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return cartLists.size();
        }

        private class wishlistData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("product_id", sProductId);
                hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "wishlist.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equals("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                        //sp.edit().putString(ConstantSp.PRODUCTID, ConstantSp.PRODUCTID).commit();
                        //sp.edit().putString(ConstantSp.PRODUCTNAME, ConstantSp.PRODUCTNAME).commit();
                        //context.startActivity(new Intent(context, WishlistFragment.class));
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        private class deleteData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sCartId);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deletecartlist.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equals("True")) {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public class MyHolder extends RecyclerView.ViewHolder {

            TextView name, quantity, price,cartQuantity;
            ImageView iv, wishlist, delete, plus, minus;

            public MyHolder(@NonNull View itemView) {
                super(itemView);
                name = itemView.findViewById(R.id.cartlist_name);
                quantity = itemView.findViewById(R.id.cartlist_quantity);
                cartQuantity = itemView.findViewById(R.id.cartlist_cart_quantity);
                price = itemView.findViewById(R.id.cartlist_price);
                iv = itemView.findViewById(R.id.cartlist_iv);
                wishlist = itemView.findViewById(R.id.custom_cart_product_wishlist);
                delete = itemView.findViewById(R.id.custom_cart_product_delete);
                plus = itemView.findViewById(R.id.custom_cart_plus);
                minus = itemView.findViewById(R.id.custom_cart_minus);
            }
        }

        private class updateCartData extends AsyncTask<String, String, String> {

            ProgressDialog pd;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pd = new ProgressDialog(context);
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();
            }

            @Override
            protected String doInBackground(String... strings) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("id", sCartId);
                hashMap.put("quantity", sQty);
                return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateCart.php", MakeServiceCall.POST, hashMap);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pd.dismiss();
                try {
                    JSONObject object = new JSONObject(s);
                    if (object.getString("Status").equals("True")) {
                        cartLists = new ArrayList<>();
                        gridView.setAdapter(null);
                        new cartData().execute();
                    } else {
                        Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}



