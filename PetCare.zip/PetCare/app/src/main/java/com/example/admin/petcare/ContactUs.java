package com.example.admin.petcare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class ContactUs extends AppCompatActivity {
    ImageButton back;

    EditText name, contact, message;
    Button send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        getSupportActionBar().hide();

        back = findViewById(R.id.cus_back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        name = findViewById(R.id.contactName);
        contact = findViewById(R.id.contactCno);
        message = findViewById(R.id.contactMessage);
        send = findViewById(R.id.Admin_adoptionAdd);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().equalsIgnoreCase("")) {
                    name.setError("Name Required");
                } else if (contact.getText().toString().trim().equalsIgnoreCase("")) {
                    contact.setError("Contact No. Required");
                } else if (contact.getText().toString().length() < 10 || contact.getText().toString().length() > 10) {
                    contact.setError("Valid Contact No. Required");
                } else if (message.getText().toString().trim().equalsIgnoreCase("")) {
                    message.setError("Message Required");
                } else {
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            ConstantSp.DEFAULT_MAIL
                    });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Contact Us of Petcare");
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Name : " + name.getText().toString() + "\n" + "Contact No. : " + contact.getText().toString() + "\n" + "Feedback Message : " + message.getText().toString());
                    emailIntent.setType("message/rfc822");

                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(ContactUs.this,
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
