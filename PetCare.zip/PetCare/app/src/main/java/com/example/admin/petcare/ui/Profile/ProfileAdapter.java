package com.example.admin.petcare.ui.Profile;

import android.content.Context;
import android.media.Image;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.petcare.R;

class ProfileAdapter extends BaseAdapter {

    Context context;
    String[] pets;
    int[] arr;


    public ProfileAdapter(Context context1, String[] pets, int[] arr) {
        this.context=context1;
        this.pets=pets;
        this.arr=arr;

    }

    @Override
    public int getCount() {
        return pets.length;
    }

    @Override
    public Object getItem(int position) {
        return pets[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.profile_layout,null);

        TextView name = view.findViewById(R.id.pro_name);
        ImageView iv= view.findViewById(R.id.pro_img);
        name.setText(pets[position]);
        iv.setImageResource(arr[position]);

        return view;


    }
}
