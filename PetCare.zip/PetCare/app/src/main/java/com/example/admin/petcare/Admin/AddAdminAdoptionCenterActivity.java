package com.example.admin.petcare.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class AddAdminAdoptionCenterActivity extends AppCompatActivity {

    Button add_AdoptionCenter;
    EditText adoption_name, adoption_add, adoption_cno, adoption_email;
    String email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_admin_adoption_center);
        getSupportActionBar().setTitle("Add Aoption Center");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        adoption_add = findViewById(R.id.add_admin_adoption_center_adoptionAddress);
        adoption_name = findViewById(R.id.add_admin_adoption_center_adoptionName);
        adoption_cno = findViewById(R.id.add_admin_adoption_center_adoptionContact);
        adoption_email = findViewById(R.id.add_admin_adoption_center_adoptionEmail);
        add_AdoptionCenter = findViewById(R.id.add_admin_adoption_center_adoptionAdd);

        add_AdoptionCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (adoption_name.getText().toString().trim().equalsIgnoreCase("")) {
                    adoption_name.setError("Name Required");
                } else if (adoption_add.getText().toString().trim().equalsIgnoreCase("")) {
                    adoption_add.setError("Address Required");
                } else if (adoption_cno.getText().toString().trim().equalsIgnoreCase("")) {
                    adoption_cno.setError("Contact No. Required");
                } else if (adoption_cno.getText().toString().trim().length() < 10 || adoption_cno.getText().toString().trim().length() > 10) {
                    adoption_cno.setError("Valid Contact No. Required");
                } else if (adoption_email.getText().toString().trim().equalsIgnoreCase("")) {
                    adoption_email.setError("Email Id Required");
                } else if (!adoption_email.getText().toString().matches(email_pattern)) {
                    adoption_email.setError("Valid Email Id Required");
                } else {
                    if (new ConnectionDetector(AddAdminAdoptionCenterActivity.this).isConnectingToInternet()) {
                        new insertAdoptiondata().execute();

                    } else {
                        new ConnectionDetector(AddAdminAdoptionCenterActivity.this).connectiondetect();

                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class insertAdoptiondata extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AddAdminAdoptionCenterActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("a_name", adoption_name.getText().toString());
            hashMap.put("a_email", adoption_email.getText().toString());
            hashMap.put("a_contact", adoption_cno.getText().toString());
            hashMap.put("a_address", adoption_add.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addAdminAdoption.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(AddAdminAdoptionCenterActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    onBackPressed();
                    /*Intent intent = new Intent(AddAdminAdoptionCenterActivity.this, AddAdminAdoptionCenterActivity.class);
                    startActivity(intent);*/
                } else {
                    Toast.makeText(AddAdminAdoptionCenterActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}