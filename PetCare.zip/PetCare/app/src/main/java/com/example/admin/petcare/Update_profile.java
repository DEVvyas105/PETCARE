package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Update_profile extends AppCompatActivity {

    ImageButton back;
    Spinner state, city;
    EditText name, email, contact, address, pincod;
    Button chnage;
    String semail, email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    String[] state_array = {"Select state", "Gujarat", "Maharashtra", "Madhya Pradesh", "Punjab", "Uttar Pradesh",
            "Delhi", "Haryana", "Uttarakhand", "Tamil Nadu", "Goa", "Kerala", "Jammu & Kashmir",
            "Andhra Pradesh", "Rajasthan", "Karnataka", "West Bengal", "Odisha", "Chhattisgarh", "Assam",
            "Himachal Pradesh", "Bihar", "Jharkhand", "Mizoram", "Nagaland", "Telangana", "Arunachal Pradesh",
            "Meghalaya", "Sikkim", "Tripura", "Manipur"};
    String[] city_array = {"Select city", "Surat", "Ahmedabad", "Baroda", "Rajkot", "Himmatnagar", "Gandhinagar", "Mehsana", "Surendranagar", "Bhavnagar"};
    String sCity, sState;
    SharedPreferences sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
        getSupportActionBar().hide();

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        back = findViewById(R.id.up_back);
        name = findViewById(R.id.profile_name);
        email = findViewById(R.id.profile_email);
        contact = findViewById(R.id.profile_cno);
        address = findViewById(R.id.profile_address);
        pincod = findViewById(R.id.profile_pincode);
        chnage = findViewById(R.id.profile_button);
        state = findViewById(R.id.profile_state);
        city = findViewById(R.id.profile_city);

        ArrayAdapter city_adapter = new ArrayAdapter(Update_profile.this, android.R.layout.simple_list_item_1, city_array);
        city.setAdapter(city_adapter);
        city.setSelection(2);

        city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sCity = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final ArrayAdapter state_adapter = new ArrayAdapter(Update_profile.this, android.R.layout.simple_list_item_1, state_array);
        state.setAdapter(state_adapter);
        state.setSelection(1);

        state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sState = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        chnage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                semail = email.getText().toString();
                if (name.getText().toString().equals("")) {
                    name.setError("Please enter your name");
                } else if (email.getText().toString().equalsIgnoreCase("")) {
                    email.setError("Please enter email-id");
                } else if (!semail.matches(email_pattern)) {
                    email.setError("Valid Email Id Required");
                    //Toast.makeText(SignupActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                } else if (contact.getText().toString().equals("")) {
                    contact.setError("Please enter contact number");
                } else if (address.getText().toString().equals("")) {
                    address.setError("Please enter address");
                } else if (pincod.getText().toString().equals("")) {
                    pincod.setError("Please enter pincode");
                } else if (city.getSelectedItemId() <= 0) {
                    Toast.makeText(Update_profile.this, "Please select city", Toast.LENGTH_LONG).show();
                } else if (state.getSelectedItemId() <= 0) {
                    Toast.makeText(Update_profile.this, "Please select state", Toast.LENGTH_LONG).show();
                } else {
                    if (new ConnectionDetector(Update_profile.this).isConnectingToInternet()) {
                        new updateData().execute();
                    } else {
                        new ConnectionDetector(Update_profile.this).connectiondetect();
                    }
                }
            }
        });
        name.setText(sp.getString(ConstantSp.NAME, ""));
        email.setText(sp.getString(ConstantSp.EMAIL, ""));
        contact.setText(sp.getString(ConstantSp.C_NO, ""));
        address.setText(sp.getString(ConstantSp.ADDRESS, ""));
        pincod.setText(sp.getString(ConstantSp.PINCODE, ""));

    }

    private class updateData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Update_profile.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sp.getString(ConstantSp.ID, ""));
            hashMap.put("name", name.getText().toString());
            hashMap.put("email", email.getText().toString());
            hashMap.put("contact", contact.getText().toString());
            hashMap.put("address", address.getText().toString());
            hashMap.put("pincode", pincod.getText().toString());
            hashMap.put("state", sState);
            hashMap.put("city", sCity);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateProfile.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(Update_profile.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    sp.edit().putString(ConstantSp.NAME, name.getText().toString()).commit();
                    sp.edit().putString(ConstantSp.EMAIL, email.getText().toString()).commit();
                    sp.edit().putString(ConstantSp.C_NO, contact.getText().toString()).commit();
                    sp.edit().putString(ConstantSp.ADDRESS, address.getText().toString()).commit();
                    sp.edit().putString(ConstantSp.PINCODE, pincod.getText().toString()).commit();
                    sp.edit().putString(ConstantSp.STATE, sState).commit();
                    sp.edit().putString(ConstantSp.CITY, sCity).commit();
                } else {
                    Toast.makeText(Update_profile.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
