package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Users_paidDetails extends AppCompatActivity {

    Button Adopt_Paidpet_user;
    TextView prize,prize_details,name,name_detail,psize,psize_detail,pheight,pheight_detail,pweight,pweight_detail,plifespan,plifespan_detail,fcno,fcno_detail,ppetname,ppetname_details;
    SharedPreferences sp;
    ImageView iv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_paid_details);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        sp=getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);


        iv=findViewById(R.id.p_image);

        name=findViewById(R.id.User_uname);
        name_detail=findViewById(R.id.UserUname_detail);
        fcno=findViewById(R.id.User_cno);
        fcno_detail=findViewById(R.id.cno_detail);
        ppetname=findViewById(R.id.pname);
        ppetname_details=findViewById(R.id.pname_detail);
        psize=findViewById(R.id.psize);
        psize_detail=findViewById(R.id.psize_detail);
        pheight=findViewById(R.id.pheight);
        pheight_detail=findViewById(R.id.pheight_detail);
        pweight=findViewById(R.id.pweight);
        pweight_detail=findViewById(R.id.pweight_detail);
        plifespan=findViewById(R.id.plifespan);
        plifespan_detail=findViewById(R.id.plifespan_detail);
        prize=findViewById(R.id.pet_prize);
        prize_details=findViewById(R.id.petPrize_detail);


        if(new ConnectionDetector(Users_paidDetails.this).isConnectingToInternet())
            new getPaidData().execute();
        else{
            new ConnectionDetector(Users_paidDetails.this).connectiondetect();
        }


//        Adopt_Paidpet_user=findViewById(R.id.paid_adopt);
//        Adopt_Paidpet_user.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                Intent intent = new Intent(Users_paidDetails.this,PetPaidAdoptionActivity.class);
//                startActivity(intent);
//            }
//        });


    }
    private class getPaidData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Users_paidDetails.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("id",sp.getString(ConstantSp.PAIDId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getUserPAID.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        name_detail.setText(jsonObject.getString("u_name"));
                        Picasso.with(Users_paidDetails.this).load(ConstantSp.IMAGEURL + jsonObject.getString("u_image")).placeholder(R.drawable.logo).into(iv);
                        fcno_detail.setText(jsonObject.getString("u_cno"));
                        ppetname_details.setText(jsonObject.getString("u_petname"));
                        psize_detail.setText(jsonObject.getString("u_size"));
                        pheight_detail.setText(jsonObject.getString("u_height"));
                        pweight_detail.setText(jsonObject.getString("u_weight"));
                        plifespan_detail.setText(jsonObject.getString("u_lifespan"));
                        prize_details.setText(jsonObject.getString("u_prize"));

                    }
                }
                else{
                    Toast.makeText(Users_paidDetails.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
