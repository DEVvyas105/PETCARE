package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class PetAdoptionActivity extends AppCompatActivity {

    Button adopt;
    EditText name,email,cno,pet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_adoption);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        adopt = findViewById(R.id.adopt);
        name =findViewById(R.id.signup_name);
        email= findViewById(R.id.signup_email);
        cno= findViewById(R.id.signup_cno);
        pet=findViewById(R.id.Pet_type);

        adopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (new ConnectionDetector(PetAdoptionActivity.this).isConnectingToInternet()) {
                    new insertAdoption().execute();

                } else {
                    new ConnectionDetector(PetAdoptionActivity.this).connectiondetect();
                }
            }
        });
    }
    public class insertAdoption extends AsyncTask<String,String ,String> {
        ProgressDialog pd;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(PetAdoptionActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")

        @Override
        protected String doInBackground(String... strings) {

            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("c_name",name.getText().toString());
            hashMap.put("c_email",email.getText().toString());
            hashMap.put("c_cno",cno.getText().toString());
            hashMap.put("c_pet",pet.getText().toString());


            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"confirmAdoption.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    Toast.makeText(PetAdoptionActivity.this,object.getString("Message"),Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(PetAdoptionActivity.this, ThankYou_Activity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText( PetAdoptionActivity.this,object.getString("Message"),Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
