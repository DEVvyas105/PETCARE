package com.example.admin.petcare;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Users_petDetails extends AppCompatActivity {

    Button Adopt_Freepet_user;
    TextView name,name_detail,fsize,fsize_detail,fheight,fheight_detail,fweight,fweight_detail,flifespan,flifespan_detail,fcno,fcno_detail,fpetname,fpetname_details;
    SharedPreferences sp;
    ImageView iv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_pet_details);

        Adopt_Freepet_user =findViewById(R.id.btn_adopt1);

        sp=getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);


        iv=findViewById(R.id.p_image);
        name=findViewById(R.id.fUser_uname);
        name_detail=findViewById(R.id.fUserUname_detail);
        fcno=findViewById(R.id.fUser_cno);
        fcno_detail=findViewById(R.id.fcno_detail);
        fpetname=findViewById(R.id.fname);
        fpetname_details=findViewById(R.id.fname_detail);
        fsize=findViewById(R.id.fsize);
        fsize_detail=findViewById(R.id.fsize_detail);
        fheight=findViewById(R.id.fheight);
        fheight_detail=findViewById(R.id.fheight_detail);
        fweight=findViewById(R.id.fweight);
        fweight_detail=findViewById(R.id.fweight_detail);
        flifespan=findViewById(R.id.flifespan);
        flifespan_detail=findViewById(R.id.flifespan_detail);


        if(new ConnectionDetector(Users_petDetails.this).isConnectingToInternet()){
            new getFreeData().execute();
        }
        else{
            new ConnectionDetector(Users_petDetails.this).connectiondetect();
        }


        Adopt_Freepet_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Users_petDetails.this,PetAdoptionActivity.class);
                startActivity(intent);
            }
        });
    }

     private class getFreeData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Users_petDetails.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("id",sp.getString(ConstantSp.FREEId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getUserPetDetails.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        name_detail.setText(jsonObject.getString("u_name"));
                        Picasso.with(Users_petDetails.this).load(ConstantSp.IMAGEURL + jsonObject.getString("u_image")).placeholder(R.drawable.logo).into(iv);
                        fcno_detail.setText(jsonObject.getString("u_cno"));
                        fpetname_details.setText(jsonObject.getString("u_petname"));
                        fsize_detail.setText(jsonObject.getString("u_size"));
                        fheight_detail.setText(jsonObject.getString("u_height"));
                        fweight_detail.setText(jsonObject.getString("u_weight"));
                        flifespan_detail.setText(jsonObject.getString("u_lifespan"));

                    }
                }
                else{
                    Toast.makeText(Users_petDetails.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
