package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class WishListAdapter extends RecyclerView.Adapter<WishListAdapter.MyHolder> {
    Context context;
    ArrayList<WishtList> wishLists;
    LayoutInflater layoutInflater;
    SharedPreferences sp;
    String sCartId;

    public WishListAdapter(FragmentActivity wishlistActivity, ArrayList<WishtList> wishLists) {

        context = wishlistActivity;
        this.wishLists = wishLists;
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.wishlist_category, viewGroup, false);
        return new WishListAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int i) {
        holder.name.setText(wishLists.get(i).getName());
        holder.price.setText("Rs. "+wishLists.get(i).getPrice());
        Picasso.with(context).load(wishLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(holder.iv);
        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.PRODUCTNAME, wishLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.PRODUCTPRICE, wishLists.get(i).getPrice()).commit();
                sp.edit().putString(ConstantSp.PRODUCTIMAGE, wishLists.get(i).getImage()).commit();
                context.startActivity(new Intent(context, ShowActivity.class));
            }
        });
        if (sp.getString(ConstantSp.USERTYPE
                , "").equals("Admin")) {
            holder.delete.setVisibility(View.GONE);
            holder.addtocart.setVisibility(View.GONE);
        } else {
            holder.delete.setVisibility(View.VISIBLE);
            holder.addtocart.setVisibility(View.VISIBLE);
        }


        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    sCartId = wishLists.get(i).getId();
                    new deleteData().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });
        holder.addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    new addCart().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
                Toast.makeText(context, "Add to cart", Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return wishLists.size();
    }
/*
    @Override
    public int getCount() {
        return wishLists.size();
    }

    @Override
    public Object getItem(int i) {
        return wishLists.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        view = layoutInflater.inflate(R.layout.wishlist_category,null);
        TextView name = view.findViewById(R.id.wishlist_name);
        ImageView iv = view.findViewById(R.id.wishlists_iv);
        TextView price = view.findViewById(R.id.wishlist_price);

        ImageView delete = view.findViewById(R.id.custom_product_delete);
        ImageView addtocart = view.findViewById(R.id.custom_product_add_to_cart);

        name.setText(wishLists.get(i).getName());
        price.setText(wishLists.get(i).getName());

        if(sp.getString(ConstantSp.USER_TYPE,"").equals("Admin")){
            delete.setVisibility(View.GONE);
            addtocart.setVisibility(View.GONE);
        }
        else{
            delete.setVisibility(View.VISIBLE);
            addtocart.setVisibility(View.VISIBLE);
        }
        Picasso.with(context).load(wishLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(iv);
        name.setText(wishLists.get(i).getName());

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(new ConnectionDetector(context).isConnectingToInternet()){
                    sCartId=wishLists.get(i).getId();
                    new deleteData().execute();
                }
                else{
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });
        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(new ConnectionDetector(context).isConnectingToInternet()){
                    new addCart().execute();
                }
                else{
                    new ConnectionDetector(context).connectiondetect();
                }
                Toast.makeText(context, "Add to cart", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }*/

    private class addCart extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("quantity", "1");
            hashMap.put("id", sp.getString(ConstantSp.ID, ""));
            hashMap.put("product_id", sp.getString(ConstantSp.PRODUCTID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addcart.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

    }

    private class deleteData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sCartId);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deletewishlist.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView name, price;
        ImageView iv, delete, addtocart;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.wishlist_name);
            price = itemView.findViewById(R.id.wishlist_price);
            iv = itemView.findViewById(R.id.wishlists_iv);
            delete = itemView.findViewById(R.id.custom_product_delete);
            addtocart = itemView.findViewById(R.id.custom_product_add_to_cart);
        }
    }
}
