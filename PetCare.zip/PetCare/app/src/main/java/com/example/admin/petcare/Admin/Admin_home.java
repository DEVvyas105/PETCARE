package com.example.admin.petcare.Admin;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.DonationListActivity;
import com.example.admin.petcare.LoginActivity;
import com.example.admin.petcare.NewCaseActivity;
import com.example.admin.petcare.R;
import com.example.admin.petcare.buy.DashboardActivity;

public class Admin_home extends AppCompatActivity {

    ListView admin_Listview;
    String[] activities = {"Manage Users", "Manage Pet Details", "Manage Adoption Centers", "Manage Payments", "Manage Articles and Videos", "Manage Home Remedies", "Manage Donation", "Manage New Case", "Manage Rescuer","Manage Products", "Log Out"};

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        getSupportActionBar().setTitle("Admin Panel");
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        admin_Listview = findViewById(R.id.admin_list);

        AdminAdapter adminAdapter = new AdminAdapter(this, activities);
        admin_Listview.setAdapter((ListAdapter) adminAdapter);

        admin_Listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int itemPosition = position;
                switch (position) {
                    case 0:
                        Intent intent = new Intent(Admin_home.this, Admin_manageUser.class);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intent1 = new Intent(Admin_home.this, Admin_petDetails.class);
                        startActivity(intent1);
                        break;
                    case 2:
                        Intent intent2 = new Intent(Admin_home.this, Admin_AdoptionCenter.class);
                        startActivity(intent2);
                        break;
                    case 3:
                        Intent intent5 = new Intent(Admin_home.this, Admin_payments.class);
                        startActivity(intent5);
                        break;
                    case 4:
                        startActivity(new Intent(Admin_home.this, AdminArtVidListActivity.class));
                        break;
                    case 5:
                        startActivity(new Intent(Admin_home.this, AdminRemediesActivity.class));
                        break;
                    case 6:
                        startActivity(new Intent(Admin_home.this, DonationListActivity.class));
                        break;
                    case 7:
                        startActivity(new Intent(Admin_home.this, NewCaseActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        break;
                    case 8:
                        startActivity(new Intent(Admin_home.this, RescuerListActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        break;
                    case 9:
                        startActivity(new Intent(Admin_home.this, DashboardActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        break;
                    case 10:
                        sp.edit().clear().commit();
                        startActivity(new Intent(Admin_home.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
            }
            // ListView Clicked item value
            //String  itemValue    = (String) profile_Listview.getItemAtPosition(position);


            //Toast.makeText(getActivity(), "Position :"+itemPosition+"  ListItem : " +itemValue , Toast.LENGTH_LONG).show(); }
        });
    }

    //Admin menu

    /*public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_admin,menu);
        return true;
    }*/

    /*public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()) {
            case R.id.manage:
                Toast.makeText(this, "Switch to adoption center", Toast.LENGTH_LONG).show();
                return true;
            case R.id.replyUser:
                    Toast.makeText(this, "Reply to user", Toast.LENGTH_LONG).show();
                    return true;
            case  R.id.Settings:
                    Toast.makeText(this, "Switch to adoption center", Toast.LENGTH_LONG).show();
                     return true;

            case R.id.exit:
                finish();
                return(true);

        }
        return(super.onOptionsItemSelected(item));
    }*/
}
