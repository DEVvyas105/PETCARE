package com.example.admin.petcare.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.petcare.AllPetsTypesActivity;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {


    public LayoutInflater inflater;
    Context context;
    private ArrayList<CategoryModel> imageModelArrayList;
    SharedPreferences sp;

    public CategoryAdapter(Context context, ArrayList<CategoryModel> imageModelArrayList) {
        inflater = LayoutInflater.from(context);
        this.imageModelArrayList = imageModelArrayList;
        this.context = context;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.recycler_item, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        //holder.iv.setImageResource(imageModelArrayList.get(position).getImage_drawable());
        Picasso.with(context).load(ConstantSp.IMAGEURL+imageModelArrayList.get(position).getImage_drawable()).placeholder(R.drawable.f).into(holder.iv);
        holder.time.setText(imageModelArrayList.get(position).getName());

        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putString(ConstantSp.TYPEId, imageModelArrayList.get(position).getId()).commit();
                sp.edit().putString(ConstantSp.TYPENAME, imageModelArrayList.get(position).getName()).commit();
                Intent intent = new Intent(context, AllPetsTypesActivity.class);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageModelArrayList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView time;
        ImageView iv;

        public MyViewHolder(View itemView) {
            super(itemView);

            time = (TextView) itemView.findViewById(R.id.tv);
            iv = (ImageView) itemView.findViewById(R.id.iv);
        }

    }
}
