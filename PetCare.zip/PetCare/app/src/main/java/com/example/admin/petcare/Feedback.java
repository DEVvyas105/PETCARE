package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Feedback extends AppCompatActivity {

    EditText name, contact, msg;
    Button send;
    ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        getSupportActionBar().hide();
        name = findViewById(R.id.FeedbackName);
        contact = findViewById(R.id.feedbackCno);
        msg = findViewById(R.id.feedbackMsg);
        send = findViewById(R.id.feedback_Add);
        back = findViewById(R.id.feed_back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().equalsIgnoreCase("")) {
                    name.setError("Name Required");
                } else if (contact.getText().toString().trim().equalsIgnoreCase("")) {
                    contact.setError("Contact No. Required");
                } else if (contact.getText().toString().length() < 10 || contact.getText().toString().length() > 10) {
                    contact.setError("Valid Contact No. Required");
                } else if (msg.getText().toString().trim().equalsIgnoreCase("")) {
                    msg.setError("Message Required");
                } else {
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            ConstantSp.DEFAULT_MAIL
                    });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Feedback of Petcare");
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Name : " + name.getText().toString() + "\n" + "Contact No. : " + contact.getText().toString() + "\n" + "Feedback Message : " + msg.getText().toString());
                    emailIntent.setType("message/rfc822");

                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(Feedback.this,
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
                /*if (new ConnectionDetector(Feedback.this).isConnectingToInternet()) {
                    new Feedback.insertdata().execute();

                } else {
                    new ConnectionDetector(Feedback.this).connectiondetect();
                }*/
    }


    /*public class insertdata extends AsyncTask<String, String, String> {


        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Feedback.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", name.getText().toString());
            hashMap.put("email", email.getText().toString());
            hashMap.put("contact", contact.getText().toString());
            hashMap.put("msg", msg.getText().toString());

            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "feedback.php", MakeServiceCall.POST, hashMap);

        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(Feedback.this, object.getString("Message"), Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(Feedback.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


    }*/
}