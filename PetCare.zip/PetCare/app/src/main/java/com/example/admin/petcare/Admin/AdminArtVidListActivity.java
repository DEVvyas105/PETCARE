package com.example.admin.petcare.Admin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.admin.petcare.Admin.AdminVidFragment;
import com.example.admin.petcare.R;
import com.example.admin.petcare.ui.Video.ArticleFragment;
import com.example.admin.petcare.ui.Video.VidFragment;
import com.example.admin.petcare.ui.Video.VideoFragment;
import com.google.android.material.tabs.TabLayout;

public class AdminArtVidListActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_art_vid_list);
        getSupportActionBar().setTitle("Manage Articles and Videos");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabLayout = findViewById(R.id.admin_tab_tablayout);
        viewPager = findViewById(R.id.admin_tab_viewpager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        TabLayoutAdapter adapter = new TabLayoutAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class TabLayoutAdapter extends FragmentPagerAdapter {
        public TabLayoutAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);

        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int i) {
            switch (i) {
                case 0:
                    return "Videos";
                case 1:
                    return "Articles";
            }
            return null;
        }

        @Override
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return new AdminVidFragment();
                case 1:
                    return new AdminArticleFragment();

            }
            return null;
        }

        @Override
        public int getCount() {
            return 2;
        }

    }

}