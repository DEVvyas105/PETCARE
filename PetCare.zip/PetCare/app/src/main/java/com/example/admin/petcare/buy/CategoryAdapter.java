package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyHolder> {

    SharedPreferences sp;
    Context context;
    ArrayList<CategoryList> categoryLists;
    LayoutInflater layoutInflater;
    int iPosition;
    String sId;

    public CategoryAdapter(FragmentActivity medicineTabActivity, ArrayList<CategoryList> categoryLists) {
        this.context = medicineTabActivity;
        this.categoryLists = categoryLists;
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_category, viewGroup, false);
        return new CategoryAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int i) {
        holder.name.setText(categoryLists.get(i).getName());
        //holder.iv.setImageResource(Integer.parseInt(categoryLists.get(i).getImage()));
        Picasso.with(context).load(categoryLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(holder.iv);
        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.CATEGORYID, categoryLists.get(i).getId()).commit();
                context.startActivity(new Intent(context, ProductActivity.class));
            }
        });

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.CATEGORY_ADD_UPDATE, "Edit").commit();
                sp.edit().putString(ConstantSp.CATEGORYID, categoryLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.CATEGORYNAME, categoryLists.get(i).getName()).commit();
                sp.edit().putString(ConstantSp.CATEGORYIMAGE, categoryLists.get(i).getImage()).commit();
                context.startActivity(new Intent(context, AddCategoryActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        if (sp.getString(ConstantSp.USERTYPE, "").equalsIgnoreCase("Admin")) {
            holder.edit.setVisibility(View.VISIBLE);
            holder.delete.setVisibility(View.VISIBLE);
        } else {
            holder.edit.setVisibility(View.GONE);
            holder.delete.setVisibility(View.GONE);
        }

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    iPosition = i;
                    sId = categoryLists.get(i).getId();
                    new deleteData().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return categoryLists.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        ImageView iv;
        TextView name;
        TextView edit, delete;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.custom_category_name);
            iv = itemView.findViewById(R.id.custom_category_iv);
            edit = itemView.findViewById(R.id.custom_category_edit);
            delete = itemView.findViewById(R.id.custom_category_delete);
        }
    }

    private class deleteData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sId);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "deleteCategory.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    categoryLists.remove(iPosition);
                    notifyDataSetChanged();
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}

  /*  @Override
    public int getCount() {
        return categoryLists.size();
    }

    @Override
    public Object getItem(int i) {
        return categoryLists.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        view = layoutInflater.inflate(R.layout.custom_category,null);

        ImageView iv = view.findViewById(R.id.custom_category_iv);
        TextView name = view.findViewById(R.id.custom_category_name);
        Picasso.with(context).load(categoryLists.get(i).getImage()).placeholder(R.mipmap.ic_launcher).into(iv);
        name.setText(categoryLists.get(i).getName());

        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.CATEGORYID,categoryLists.get(i).getId()).commit();
                context.startActivity(new Intent(context,ProductActivity.class));

            }
        });
        return view;
    }*/

