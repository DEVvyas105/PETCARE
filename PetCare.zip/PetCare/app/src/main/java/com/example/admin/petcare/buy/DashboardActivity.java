package com.example.admin.petcare.buy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.LoginActivity;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

public class DashboardActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    ImageView addcart, wishlist;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        /*addcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction().replace(R.id.nav_host_fragment,new AddcartFragment()).commit();
                Toast.makeText(getApplicationContext(),"Addcart",Toast.LENGTH_SHORT).show();
            }
        });
        wishlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction().replace(R.id.nav_host_fragment,new WishlistFragment()).commit();
                Toast.makeText(getApplicationContext(),"wishlist",Toast.LENGTH_SHORT).show();
            }
        });
*/
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View headerView = navigationView.getHeaderView(0);

        TextView username = headerView.findViewById(R.id.username);
        TextView useremail = headerView.findViewById(R.id.useremail);
        TextView medicalStore = headerView.findViewById(R.id.near_medical);
        TextView hospital = headerView.findViewById(R.id.near_hospital);

        username.setText(sp.getString(ConstantSp.NAME, ""));
        useremail.setText(sp.getString(ConstantSp.EMAIL, ""));

        hospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUriHospital = Uri.parse("geo:0,0?q=hospital");
                Intent mapIntentHospital = new Intent(Intent.ACTION_VIEW, gmmIntentUriHospital);
                mapIntentHospital.setPackage("com.google.android.apps.maps");
                startActivity(mapIntentHospital);
            }
        });

        medicalStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?q=medicalstore");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_cart,
                R.id.nav_order_history)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_dashboard);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    //search menu.....


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        /*if (sp.getString(ConstantSp.SELECTMETHOD, "").equals("Cart")) {
            startActivity(new Intent(DashboardActivity.this, DashboardActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        } else {
            finishAffinity();
        }*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        /*getMenuInflater().inflate(R.menu.dashboard, menu);
        return true;*/
        getMenuInflater().inflate(R.menu.menu, menu);

        MenuItem searchViewItem = menu.findItem(R.id.menu_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchViewItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                searchView.clearFocus();
                sp.edit().putString(ConstantSp.CATEGORYID, "").commit();
                sp.edit().putString(ConstantSp.SEARCH, s).commit();
                startActivity(new Intent(DashboardActivity.this, ProductActivity.class));
             /*   if(list.contains(query)){
                    adapter.getFilter().filter(query);
                }else{
                    Toast.makeText(MainActivity.this, "No Match found",Toast.LENGTH_LONG).show();
                }*/
                return false;

            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_cart) {
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.nav_host_fragment_dashboard, new AddcartFragment()).commit();
        }
        if (id == R.id.logout) {
            sp.edit().clear().commit();
            startActivity(new Intent(DashboardActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
        }
        /*if (id == R.id.menu_wishlist){
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.nav_host_fragment,new WishlistFragment()).commit();
        }*/
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_dashboard);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
