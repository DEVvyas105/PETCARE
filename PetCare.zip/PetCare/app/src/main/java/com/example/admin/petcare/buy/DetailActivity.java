package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class DetailActivity extends AppCompatActivity {

    RecyclerView gridView;
    ArrayList<DetailList> detailLists;
    DetailAdapter adapter;

    String[] categoryName = {"Mucovib","Zincovit","Drops"};
    int[] image = {R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher};
    String[] discription = {"cough syrup","Vitamin B12 deficiency,Anaemia","3"};
    String[] power = {"100ml","200ml","33"};
    String[] price = {"Rs.37.42","Rs.119","cc"};

    TextView name,contactno,ship_address,transactionid,grandtotal;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        name = findViewById(R.id.detail_user_name);
        contactno = findViewById(R.id.detail_user_contact);
        ship_address = findViewById(R.id.detail_user_address);
        grandtotal = findViewById(R.id.detail_user_total);
        transactionid = findViewById(R.id.detail_user_transactionid);

        gridView = findViewById(R.id.detail_user_gv);
        gridView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        //name.setText(sp.getString(ConstantSp.NAME,""));
        //contactno.setText(sp.getString(ConstantSp.CONTACT,""));
        //transactionid.setText(sp.getString(ConstantSp.TRANSACTIONID,""));
        grandtotal.setText("Rs."+sp.getString(ConstantSp.TOTAL,""));
        transactionid.setText("Order No : "+sp.getString(ConstantSp.ORDERID,""));

        if (new ConnectionDetector(DetailActivity.this).isConnectingToInternet()) {
            new detailData().execute();
            new shippingData().execute();
        } else {
            new ConnectionDetector(DetailActivity.this).connectiondetect();
        }

    }

    private class detailData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(DetailActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("id", sp.getString(ConstantSp.ORDERID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "detaillist.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try{
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    grandtotal.setText("Rs."+object.getString("total"));
                    detailLists = new ArrayList<>();
                    for(int i=0; i<array.length();i++)
                    {
                        JSONObject jsonObject = array.getJSONObject(i);
                        DetailList list = new DetailList();
                        list.setName(jsonObject.getString("name"));
                        list.setPrice(jsonObject.getString("price"));
                        list.setImage(jsonObject.getString("image"));
                        detailLists.add(list);
                    }

                    adapter = new DetailAdapter(DetailActivity.this,detailLists);
                    gridView.setAdapter(adapter);
                }
                else {
                    Toast.makeText(DetailActivity.this,object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class shippingData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(DetailActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("orderId", sp.getString(ConstantSp.ORDERID, ""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "address.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try{
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    for(int i=0; i<array.length();i++)
                    {
                        JSONObject jsonObject = array.getJSONObject(i);
                        name.setText(jsonObject.getString("userName"));
                        contactno.setText(jsonObject.getString("userContact"));
                        ship_address.setText(jsonObject.getString("area")+"\n"+jsonObject.getString("city")+"\n"+jsonObject.getString("state"));
                    }

                }
                else {
                    Toast.makeText(DetailActivity.this,object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
