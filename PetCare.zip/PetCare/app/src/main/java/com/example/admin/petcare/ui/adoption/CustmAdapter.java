package com.example.admin.petcare.ui.adoption;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.admin.petcare.AdoptActivity;
import com.example.admin.petcare.R;

public class CustmAdapter extends BaseAdapter {
    Context context;
    String[] pets_array1;

    public CustmAdapter(AdoptActivity adoptActivity, String[] pets_array) {
        this.context=adoptActivity;
        pets_array1=pets_array;
    }

    @Override
    public int getCount() {
        return pets_array1.length;
    }

    @Override
    public Object getItem(int position) {
        return pets_array1[position];
    }

    @Override
    public long getItemId(int position) {
        return position ;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.custom_petlist,null);
        TextView name = view.findViewById(R.id.petname);
        name.setText(pets_array1[position]);
        return view;
    }
}
