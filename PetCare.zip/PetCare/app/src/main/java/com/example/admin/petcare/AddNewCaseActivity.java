package com.example.admin.petcare;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.admin.petcare.Admin.AddAdminRemediesActivity;

import net.gotev.uploadservice.MultipartUploadRequest;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.util.UUID;

public class AddNewCaseActivity extends AppCompatActivity {

    EditText address;
    Button captureImage, uploadImage;
    ImageView imageView;

    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 200;
    String sSelected1 = "";

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_case);
        getSupportActionBar().setTitle("Add New Case");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);
        address = findViewById(R.id.add_new_case_address);
        captureImage = findViewById(R.id.add_new_case_capture_image);
        uploadImage = findViewById(R.id.add_new_case_upload_image);

        imageView = findViewById(R.id.add_new_case_imageView);

        captureImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                    } else {
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_REQUEST);
                    }
                }
            }
        });

        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(address.getText().toString().equalsIgnoreCase("")){
                    address.setError("Address Required");
                }
                else{
                    if(sSelected1==null || sSelected1.equals("")){
                        Toast.makeText(AddNewCaseActivity.this, "Please Capture Image", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        ProgressDialog pd = new ProgressDialog(AddNewCaseActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        String uploadId = UUID.randomUUID().toString();

                        //Creating a multi part request
                        try {
                            new MultipartUploadRequest(AddNewCaseActivity.this, uploadId, ConstantSp.URL + "addNewCase.php")
                                    .addFileToUpload(sSelected1, "file") //Adding file
                                    .addParameter("address", address.getText().toString()) //Adding text parameter to the request
                                    .addParameter("name", sp.getString(ConstantSp.NAME,"")) //Adding text parameter to the request
                                    .addParameter("userId", sp.getString(ConstantSp.ID,"")) //Adding text parameter to the request
                                    .setMaxRetries(2)
                                    .startUpload(); //Starting the upload
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(AddNewCaseActivity.this, "New Case Added Successfully", Toast.LENGTH_SHORT).show();
                                    onBackPressed();
                                }
                            }, 3000);
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            Uri tempUri = getImageUri(getApplicationContext(), photo);
            sSelected1 = getImage(tempUri);
            imageView.setImageBitmap(photo);
            //setImage();
        }
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private String getImage(Uri uri) {
        if (uri != null) {
            String path = null;
            String[] s_array = {MediaStore.Images.Media.DATA};
            Cursor c = managedQuery(uri, s_array, null, null, null);
            int id = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            if (c.moveToFirst()) {
                do {
                    path = c.getString(id);
                }
                while (c.moveToNext());
                //c.close();
                if (path != null) {
                    return path;
                }
            }
        }
        return "";
    }

}