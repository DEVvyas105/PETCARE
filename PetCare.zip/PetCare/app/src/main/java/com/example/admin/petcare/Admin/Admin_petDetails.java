package com.example.admin.petcare.Admin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.admin.petcare.R;
import com.google.android.material.tabs.TabLayout;

public class Admin_petDetails extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_pet_details);
        getSupportActionBar().setTitle("Pet Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabLayout = findViewById(R.id.admin_pet_details_tablayout);
        viewPager = findViewById(R.id.admin_pet_details_viewpager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        UserAdapter adapter = new UserAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        //menu on action bar
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return (true);
        }
        return (super.onOptionsItemSelected(item));
    }


    private class UserAdapter extends FragmentPagerAdapter {


        public UserAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Free Adoption";
                case 1:
                    return "Paid Adoption";
            }
            return null;
        }

        @Override
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return new AdminFreeFragment();
                case 1:
                    return new AdminPaidFragment();

            }
            return null;
        }

        @Override
        public int getCount() {
            return 2;
        }

    }
}
