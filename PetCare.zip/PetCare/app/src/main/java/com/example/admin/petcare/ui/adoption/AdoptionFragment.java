package com.example.admin.petcare.ui.adoption;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.example.admin.petcare.UserActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;

public class AdoptionFragment extends Fragment {

    ListView listView;
    SharedPreferences sp;
    Button user;
    ArrayList<AllAdoption> allAdoption;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_adoption, container, false);

        sp=getActivity().getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);

        listView = root.findViewById(R.id.expand);
        user = root.findViewById(R.id.userTouser);

        if(new ConnectionDetector(getActivity()).isConnectingToInternet()){
            new getAdoptionData().execute();
        }
        else{
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(getContext(),UserActivity.class);
                startActivity(intent);
            }
        });

        return root;
    }


    private class getAdoptionData extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"getAdoptionCenter.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    JSONArray array = object.getJSONArray("response");
                    allAdoption = new ArrayList<>();
                    for(int i=0;i<array.length();i++){
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllAdoption list = new AllAdoption();
                        list.setId(jsonObject.getString("id"));
                        list.setName(jsonObject.getString("a_name"));
                        list.setImage(jsonObject.getString("a_image"));
                        list.setContact(jsonObject.getString("a_contact"));
                        list.setAddress(jsonObject.getString("a_address"));
                        allAdoption.add(list);
                    }
                    AdoptionAdapter adoptionadapter = new AdoptionAdapter(getActivity(),allAdoption);
                    listView.setAdapter((ListAdapter) adoptionadapter);

                }
                else{
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
