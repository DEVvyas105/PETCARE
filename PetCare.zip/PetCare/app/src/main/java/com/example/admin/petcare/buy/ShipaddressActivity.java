package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.PaymentFiles.ProgressUtils;
import com.example.admin.petcare.R;
import com.payumoney.core.PayUmoneyConfig;
import com.payumoney.core.PayUmoneySdkInitializer;
import com.payumoney.core.entity.TransactionResponse;
import com.payumoney.sdkui.ui.utils.PayUmoneyFlowManager;
import com.payumoney.sdkui.ui.utils.ResultModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ShipaddressActivity extends AppCompatActivity {

    EditText email, area, pincode, cno;
    Button submit;
    Spinner cityspinner,statespinner;
    SharedPreferences sp;
    String sTransactionType, sTransactionId;

    String[] statelist =  {"Andhrapradesh","Assam","Arunachalpradesh","Bihar","Bhopal","Chattishgarh","Goa","Gujarat","Hariyana","Rajsthan","Manipur","Maharastra"};
    String[] citylist = {"Ahmedabd","Ambaji","Anand","Ankleshwar","Bardoli","Baroda","Bharuch","Bhuj","Bhavnagar","Botad","Rajkot","Surat","Jamnagar","Gandhinagar"};

    String sCity,sState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shipaddress);

        area = findViewById(R.id.sh_area);
        email = findViewById(R.id.sh_email);
        cityspinner = findViewById(R.id.sh_city);
        statespinner = findViewById(R.id.sh_state);
        pincode = findViewById(R.id.sh_pin);
        cno = findViewById(R.id.sh_cno);
        submit = findViewById(R.id.sh_submit);

        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        email.setText(sp.getString(ConstantSp.EMAIL, ""));
        area.setText(sp.getString(ConstantSp.AREA, ""));
        cno.setText(sp.getString(ConstantSp.C_NO, ""));
        pincode.setText(sp.getString(ConstantSp.PINCODE, ""));

        ArrayAdapter cityAdapter = new ArrayAdapter(ShipaddressActivity.this, android.R.layout.simple_list_item_checked,citylist);
        cityspinner.setAdapter(cityAdapter);

        ArrayAdapter stateAdapter = new ArrayAdapter(ShipaddressActivity.this, android.R.layout.simple_list_item_checked,statelist);
        statespinner.setAdapter(stateAdapter);

        statespinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sState = statelist[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        cityspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sCity = citylist[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (area.getText().toString().equals("")) {
                    area.setError("Area required..");
                }/* else if (city.getText().toString().equals("")) {
                    city.setError("city required..");
                } else if (state.getText().toString().equals("")) {
                    state.setError("state required..");
                }*/ else if (pincode.getText().toString().equals("")) {
                    pincode.setError("pincode required..");
                } else if (email.getText().toString().equals("")) {
                    email.setError("Email ID rquired..");
                } else if (cno.getText().toString().equals("")) {
                    cno.setError("Contactno required...");
                } else {
                    if (new ConnectionDetector(ShipaddressActivity.this).isConnectingToInternet()) {
                        new shipaddress().execute();
                    } else {
                        new ConnectionDetector(ShipaddressActivity.this).connectiondetect();
                    }
                }
            }
        });

    }

    private class shipaddress extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ShipaddressActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            hashMap.put("area", area.getText().toString());
            hashMap.put("userEmail", email.getText().toString());
            hashMap.put("city", sCity);
            hashMap.put("state", sState);
            hashMap.put("userContact", cno.getText().toString());
            hashMap.put("pincode", pincode.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "shipaddress.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    sp.edit().putString(ConstantSp.SHIPPINGID, object.getString("id")).commit();
                    AlertDialog.Builder builder = new AlertDialog.Builder(ShipaddressActivity.this);
                    builder.setTitle("Payment Mode");
                    builder.setMessage("Select Payment method");
                    builder.setPositiveButton("Credit Card / Debit Card", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            sTransactionType = "ONLINE";
                            launchPaymentFlow();
                            /*Toast.makeText(ShipaddressActivity.this, "Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(ShipaddressActivity.this, OrderPlacedActivity.class));*/
                        }
                    });
                    builder.setNeutralButton("Cash On Delivery", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            sTransactionType = "COD";
                            sTransactionId = "";
                            if (new ConnectionDetector(ShipaddressActivity.this).isConnectingToInternet()) {
                                new updateOrderData().execute();
                            } else {
                                new ConnectionDetector(ShipaddressActivity.this).connectiondetect();
                            }
                        }
                    });
                    builder.show();
                } else {
                    Toast.makeText(ShipaddressActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class updateOrderData extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ShipaddressActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            hashMap.put("shippingId", sp.getString(ConstantSp.SHIPPINGID, ""));
            hashMap.put("totalAmount", sp.getString(ConstantSp.TOTAL,""));
            hashMap.put("transactionType", sTransactionType);
            hashMap.put("transactionId", sTransactionId);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addOrder.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(ShipaddressActivity.this, "Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ShipaddressActivity.this, OrderPlacedActivity.class));
                } else {
                    Toast.makeText(ShipaddressActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void launchPaymentFlow() {
        PayUmoneyConfig payUmoneyConfig = PayUmoneyConfig.getInstance();
        payUmoneyConfig.setPayUmoneyActivityTitle("Buy Order");
        payUmoneyConfig.setDoneButtonText("Pay " + getResources().getString(R.string.Rupees) + sp.getString(ConstantSp.TOTAL,""));
        //setTxnId(System.currentTimeMillis() + "")
        PayUmoneySdkInitializer.PaymentParam.Builder builder = new PayUmoneySdkInitializer.PaymentParam.Builder();
        builder.setAmount(String.valueOf(convertStringToDouble(sp.getString(ConstantSp.TOTAL,""))))
                .setTxnId("1234567890")
                .setPhone("+91"+sp.getString(ConstantSp.C_NO,""))
                .setProductName("User Order")
                .setFirstName(sp.getString(ConstantSp.NAME,""))
                .setEmail(sp.getString(ConstantSp.EMAIL,""))
                .setsUrl(ConstantSp.SURL)
                .setfUrl(ConstantSp.FURL)
                .setUdf1("")
                .setUdf2("")
                .setUdf3("")
                .setUdf4("")
                .setUdf5("")
                .setUdf6("")
                .setUdf7("")
                .setUdf8("")
                .setUdf9("")
                .setUdf10("")
                .setIsDebug(ConstantSp.DEBUG)
                .setKey(ConstantSp.MERCHANT_KEY)
                .setMerchantId(ConstantSp.MERCHANT_ID);
        try {
            PayUmoneySdkInitializer.PaymentParam mPaymentParams = builder.build();
            calculateHashInServer(mPaymentParams);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void calculateHashInServer(final PayUmoneySdkInitializer.PaymentParam mPaymentParams) {
        ProgressUtils.showLoadingDialog(this);
        String url = ConstantSp.MONEY_HASH;
        StringRequest request = new StringRequest(Request.Method.POST, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String merchantHash = "";

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            merchantHash = jsonObject.getString("result");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        ProgressUtils.cancelLoading();

                        if (merchantHash.isEmpty() || merchantHash.equals("")) {
                            Toast.makeText(ShipaddressActivity.this, "Could not generate hash", Toast.LENGTH_SHORT).show();
                        } else {
                            mPaymentParams.setMerchantHash(merchantHash);
                            PayUmoneyFlowManager.startPayUMoneyFlow(mPaymentParams, ShipaddressActivity.this, R.style.PayUMoney, true);
                        }
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (error instanceof NoConnectionError) {
                            Toast.makeText(ShipaddressActivity.this, "Connect to internet Volley", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ShipaddressActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        ProgressUtils.cancelLoading();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                return mPaymentParams.getParams();
            }
        };
        Volley.newRequestQueue(this).add(request);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PayUmoneyFlowManager.REQUEST_CODE_PAYMENT && resultCode == RESULT_OK && data != null) {

            TransactionResponse transactionResponse = data.getParcelableExtra(PayUmoneyFlowManager.INTENT_EXTRA_TRANSACTION_RESPONSE);
            ResultModel resultModel = data.getParcelableExtra(PayUmoneyFlowManager.ARG_RESULT);

            if (transactionResponse != null && transactionResponse.getPayuResponse() != null) {

                if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.SUCCESSFUL)) {
                    //showAlert("Payment Successful");
                    sTransactionId = transactionResponse.getTransactionDetails();
                    Toast.makeText(this, "Payment Successfully", Toast.LENGTH_SHORT).show();
                    if (new ConnectionDetector(ShipaddressActivity.this).isConnectingToInternet()) {
                        new updateOrderData().execute();
                    } else {
                        new ConnectionDetector(ShipaddressActivity.this).connectiondetect();
                    }
                } else if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.CANCELLED)) {
                    showAlert("Payment Cancelled");
                } else if (transactionResponse.getTransactionStatus().equals(TransactionResponse.TransactionStatus.FAILED)) {
                    showAlert("Payment Failed");
                }

            } else if (resultModel != null && resultModel.getError() != null) {
                Toast.makeText(this, "Error check log", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Both objects are null", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == PayUmoneyFlowManager.REQUEST_CODE_PAYMENT && resultCode == RESULT_CANCELED) {
            showAlert("Payment Cancelled");
        }
    }

    private Double convertStringToDouble(String str) {
        return Double.parseDouble(str);
    }

    private void showAlert(String msg) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setMessage(msg);
        alertDialog.setCancelable(false);
        alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alertDialog.show();
    }

}
