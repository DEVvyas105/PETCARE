package com.example.admin.petcare;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.admin.petcare.ui.adoption.AdoptionFragment;
import com.google.android.material.tabs.TabLayout;

public class PetHistoryActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_history);
        getSupportActionBar().setTitle("Pet Adobtion History");

        tabLayout = findViewById(R.id.pet_history_tablayout);
        viewPager = findViewById(R.id.pet_history_viewpager);

        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        PetHistoryAdapter adapter = new PetHistoryAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);

        //menu on action bar
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.adoption:
            /*Intent intent =new Intent(UserActivity.this, AdoptionFragment.class);
            startActivity(intent);*/
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction().replace(R.id.content, new AdoptionFragment()).addToBackStack("").commit();
                //Toast.makeText(this, "Switch to adoption center", Toast.LENGTH_LONG).show();
                return (true);
            case R.id.exit:
                finish();
                return (true);

        }
        return (super.onOptionsItemSelected(item));
    }


    private class PetHistoryAdapter extends FragmentPagerAdapter {

        public PetHistoryAdapter(FragmentManager supportFragmentManager) {
            super(supportFragmentManager);
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Own Pets";
                case 1:
                    return "Adopted Pets";
            }
            return null;
        }

        @Override
        public Fragment getItem(int i) {
            switch (i) {
                case 0:
                    return new OwnPetsFragment();
                case 1:
                    return new AdoptedPetsFragment();

            }
            return null;
        }

        @Override
        public int getCount() {
            return 2;
        }

    }
}