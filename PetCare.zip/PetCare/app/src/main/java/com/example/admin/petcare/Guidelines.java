package com.example.admin.petcare;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class Guidelines extends AppCompatActivity {
    ListView guideList;
    String[] guide_array={"Keep pets on a leash when taking them out of the house","Keep your pets quiet,especially at night","Train pets to poop in your house or in designated areas.","Carry newspapers while on walks, in case they dirty common areas."," Keep your pets away from those who are afraid or uncomfortable with animals."," Do periodical vaccination and routine health check-ups." ,"Abide by the by-laws laid down by the Apartment Ass"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guidelines);

        guideList=findViewById(R.id.guide_list);

        GuidelineAdapter guidelineAdapter = new GuidelineAdapter(Guidelines.this,guide_array);
        guideList.setAdapter(guidelineAdapter);

    }
}
