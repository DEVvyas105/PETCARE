package com.example.admin.petcare;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class AdoptedPetsAdapter extends RecyclerView.Adapter<AdoptedPetsAdapter.MyHolder> {

    Context context;
    ArrayList<AdoptedPetsList> allFreePets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public AdoptedPetsAdapter(Context context, ArrayList<AdoptedPetsList> allFreePets) {
        this.context = context;
        this.allFreePets = allFreePets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_adopted_pets, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        if (allFreePets.get(position).getPrice().equalsIgnoreCase("")) {
            holder.petName.setText(allFreePets.get(position).getPetname());
        } else {
            holder.petName.setText(allFreePets.get(position).getPetname() + " ( " + context.getResources().getString(R.string.rs_symbol) + allFreePets.get(position).getPrice() + " )");
        }
        holder.height.setText(allFreePets.get(position).getHeight() + " Inch");
        holder.weight.setText(allFreePets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allFreePets.get(position).getLifespan() + " Year");
        holder.name.setText(allFreePets.get(position).getName());
        holder.email.setText(allFreePets.get(position).getEmail());
        holder.contact.setText(allFreePets.get(position).getContactNo());

        if(allFreePets.get(position).getAdopted_username().equalsIgnoreCase("")){
            holder.adoptedUsernameLayout.setVisibility(View.GONE);
        }
        else{
            holder.adoptedUsernameLayout.setVisibility(View.VISIBLE);
            holder.adoptedName.setText(allFreePets.get(position).getAdopted_username());
        }

        if (allFreePets.get(position).getType().equalsIgnoreCase("Free")) {
            holder.paymentStatusLayout.setVisibility(View.GONE);
        } else {
            holder.paymentStatusLayout.setVisibility(View.VISIBLE);
            if (allFreePets.get(position).getTransactionId() == null || allFreePets.get(position).getTransactionId().equalsIgnoreCase("null") || allFreePets.get(position).getTransactionId().equalsIgnoreCase("")) {
                holder.paymentStatus.setText("Pending");
            } else {
                holder.paymentStatus.setText("Received");
            }
        }
    }

    @Override
    public int getItemCount() {
        return allFreePets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact, paymentStatus,adoptedName;
        LinearLayout paymentStatusLayout,adoptedUsernameLayout;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.custom_adopted_pets_petname);
            height = itemView.findViewById(R.id.custom_adopted_pets_height);
            weight = itemView.findViewById(R.id.custom_adopted_pets_wight);
            lifespan = itemView.findViewById(R.id.custom_adopted_pets_lifespan);
            name = itemView.findViewById(R.id.custom_adopted_pets_name);
            email = itemView.findViewById(R.id.custom_adopted_pets_email);
            contact = itemView.findViewById(R.id.custom_adopted_pets_contact);
            paymentStatus = itemView.findViewById(R.id.custom_adopted_pets_payment_status);
            paymentStatusLayout = itemView.findViewById(R.id.custom_adopted_pets_payment_status_layout);
            adoptedName = itemView.findViewById(R.id.custom_adopted_pets_adopted_username);
            adoptedUsernameLayout = itemView.findViewById(R.id.custom_adopted_pets_adopted_username_layout);
        }
    }
}
