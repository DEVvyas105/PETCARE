package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class ShowActivity extends AppCompatActivity {

    TextView name,description,price;
    ImageView iv;
    Button wishlist,addcart;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        /*getSupportActionBar().setIcon(R.mipmap.logo);*/
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sp = getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);

        name = findViewById(R.id.show_prod_name);
        description = findViewById(R.id.show_prod_description);
        price = findViewById(R.id.show_prod_Price);
        iv = findViewById(R.id.show_prod_image);
        addcart = findViewById(R.id.add);
        //wishlist = findViewById(R.id.wish);
        iv.setImageResource(R.mipmap.ic_launcher);

        name.setText(sp.getString(ConstantSp.PRODUCTNAME,""));
        description.setText(sp.getString(ConstantSp.PRODUCTDESCRIPTION,""));
        price.setText("Rs. "+sp.getString(ConstantSp.PRODUCTPRICE,""));
        Picasso.with(ShowActivity.this).load(sp.getString(ConstantSp.PRODUCTIMAGE,"")).placeholder(R.mipmap.ic_launcher).into(iv);


        if(sp.getString(ConstantSp.USERTYPE,"").equals("Admin")){
            addcart.setVisibility(View.GONE);
            //wishlist.setVisibility(View.GONE);
        }
        else{
            addcart.setVisibility(View.VISIBLE);
            //wishlist.setVisibility(View.VISIBLE);
        }

        /*wishlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(new ConnectionDetector(ShowActivity.this).isConnectingToInternet()){
                   *//* sp.edit().putString(ConstantSp.PRODUCTID,ConstantSp.PRODUCTID).commit();
                    sp.edit().putString(ConstantSp.PRODUCTNAME,ConstantSp.PRODUCTNAME).commit();*//*
                    new wishlistData().execute();
                }
                else{
                    new ConnectionDetector(ShowActivity.this).connectiondetect();
                }
            }
        });
*/
        addcart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(new ConnectionDetector(ShowActivity.this).isConnectingToInternet()){
                    new cartData().execute();
                }
                else{
                    new ConnectionDetector(ShowActivity.this).connectiondetect();
                }
            }
        });
    }

    private class cartData extends AsyncTask<String, String, String> {

        ProgressDialog pd;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ShowActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("product_id",sp.getString(ConstantSp.PRODUCTID,""));
            hashMap.put("userId",sp.getString(ConstantSp.ID,""));
            hashMap.put("quantity","1");
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"addcart.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    Toast.makeText(ShowActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    /*FragmentManager manager = getSupportFragmentManager();
                    manager.beginTransaction().replace(R.id.show_activity,new AddcartFragment()).commit();*/
                    //startActivity(new Intent(ShowActivity.this,LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                }
                else{
                    Toast.makeText(ShowActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class wishlistData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ShowActivity.this);
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            //hashMap.put("product_id",sp.getString(ConstantSp.PRODUCTID,""));
            hashMap.put("id",sp.getString(ConstantSp.ID,""));
            hashMap.put("product_id",sp.getString(ConstantSp.PRODUCTID,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL+"wishlist.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equals("True")){
                    Toast.makeText(ShowActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    //startActivity(new Intent(ShowActivity.this,LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    FragmentManager manager = getSupportFragmentManager();
                    manager.beginTransaction().replace(R.id.show_activity,new WishlistFragment()).commit();
                }
                else{
                    Toast.makeText(ShowActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}
