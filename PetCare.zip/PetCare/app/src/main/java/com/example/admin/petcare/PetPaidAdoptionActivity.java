package com.example.admin.petcare;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class PetPaidAdoptionActivity extends AppCompatActivity {

    Button adopt,home;
    EditText name,email,cno;
    Spinner pettype;
    String sGender;
    String[] pet_array = {"<<-Select->>","Dog","Cat","Fish","Monkey","Goat","Rabbits","Rat"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_paid_adoption);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        adopt = findViewById(R.id.adopt);
        name =findViewById(R.id.signup_name);
        email= findViewById(R.id.signup_email);
        cno= findViewById(R.id.signup_cno);
        pettype=findViewById(R.id.petType);
        home = findViewById(R.id.home);

        ArrayAdapter gender_adapter = new ArrayAdapter(PetPaidAdoptionActivity.this,android.R.layout.simple_list_item_1,pet_array);
        pettype.setAdapter(gender_adapter);



        pettype.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                sGender = (String) parent.getItemAtPosition( position );
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        } );

        adopt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(PetPaidAdoptionActivity.this, PaymentActivity.class);
                startActivity(intent);
              //  Toast.makeText(PetPaidAdoptionActivity.this, "ADoption Sucessfull.....", Toast.LENGTH_SHORT).show();

            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PetPaidAdoptionActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}
