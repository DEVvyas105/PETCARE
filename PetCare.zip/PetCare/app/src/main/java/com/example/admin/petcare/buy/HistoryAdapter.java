package com.example.admin.petcare.buy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyHolder> {

    Context context;
    ArrayList<HistoryList> historyLists;
    LayoutInflater layoutInflater;
    SharedPreferences sp;

    public HistoryAdapter(FragmentActivity historyActivity, ArrayList<HistoryList> historyLists) {

        this.context = historyActivity;
        this.historyLists = historyLists;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.custom_history, viewGroup, false);
        return new HistoryAdapter.MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int i) {
        holder.amount.setText("Rs."+historyLists.get(i).getTotalAmount());
        holder.date.setText(historyLists.get(i).getDate());
        holder.status.setText(historyLists.get(i).getStatus());
        holder.id.setText("Order No : "+historyLists.get(i).getId());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sp.edit().putString(ConstantSp.ORDERID,historyLists.get(i).getId()).commit();
                sp.edit().putString(ConstantSp.TOTAL,historyLists.get(i).getTotalAmount()).commit();
                context.startActivity(new Intent(context,DetailActivity.class));
            }
        });

    }

    @Override
    public int getItemCount() {
        return historyLists.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder{

        TextView id,amount,status,date;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.custom_h_id);
            amount = itemView.findViewById(R.id.custom_h_price);
            date = itemView.findViewById(R.id.custom_h_date);
            status = itemView.findViewById(R.id.custom_h_status);
        }
    }

    /*@Override
    public int getCount() {
        return historyLists.size();
    }

    @Override
    public Object getItem(int i) {
        return historyLists.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.custom_history, null);

        TextView name = view.findViewById(R.id.custom_h_name);
        TextView id = view.findViewById(R.id.custom_h_id);

        name.setText(historyLists.get(i).getName());
        id.setText(historyLists.get(i).getId());

        sp.edit().putString(ConstantSp.PRODUCTID,historyLists.get(i).getId()).commit();
        name.setText(sp.getString(ConstantSp.PRODUCTNAME,""));
        price.setText(sp.getString(ConstantSp.PRODUCTPRICE,""));
        Picasso.with(context).load(ConstantSp.PRODUCTIMAGE).placeholder(R.mipmap.ic_launcher).into(iv);
*//*
        return view;
    }*/
}
