package com.example.admin.petcare.Admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.R;

import java.util.ArrayList;

public class CustomAdminFreeAdapter extends RecyclerView.Adapter<CustomAdminFreeAdapter.MyHolder> {

    Context context;
    ArrayList<AllFreePets> allFreePets;
    SharedPreferences sp;
    String sAdoptId;
    int iPosition;

    public CustomAdminFreeAdapter(Context context, ArrayList<AllFreePets> allFreePets) {
        this.context = context;
        this.allFreePets = allFreePets;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.admin_pet_grid, parent, false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        holder.petName.setText(allFreePets.get(position).getPetname());
        holder.height.setText(allFreePets.get(position).getHeight() + " Inch");
        holder.weight.setText(allFreePets.get(position).getWeight() + " KG");
        holder.lifespan.setText(allFreePets.get(position).getLifespan() + " Year");
        holder.name.setText(allFreePets.get(position).getName());
        holder.email.setText(allFreePets.get(position).getEmail());
        holder.contact.setText(allFreePets.get(position).getContactNo());

        if (allFreePets.get(position).getFromDate().equalsIgnoreCase("") && allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
            holder.dateLayout.setVisibility(View.GONE);
        } else {
            holder.dateLayout.setVisibility(View.VISIBLE);
            if (allFreePets.get(position).getFromDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getToDate());
            } else if (allFreePets.get(position).getToDate().equalsIgnoreCase("")) {
                holder.date.setText(allFreePets.get(position).getFromDate());
            } else {
                holder.date.setText(allFreePets.get(position).getFromDate() + " To " + allFreePets.get(position).getToDate());
            }
        }

    }

    @Override
    public int getItemCount() {
        return allFreePets.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView petName, height, weight, lifespan, name, email, contact, date;
        LinearLayout dateLayout;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            petName = itemView.findViewById(R.id.admin_pet_grid_petname);
            height = itemView.findViewById(R.id.admin_pet_grid_height);
            weight = itemView.findViewById(R.id.admin_pet_grid_wight);
            lifespan = itemView.findViewById(R.id.admin_pet_grid_lifespan);
            name = itemView.findViewById(R.id.admin_pet_grid_name);
            email = itemView.findViewById(R.id.admin_pet_grid_email);
            contact = itemView.findViewById(R.id.admin_pet_grid_contact);
            date = itemView.findViewById(R.id.admin_pet_grid_date);
            dateLayout = itemView.findViewById(R.id.admin_pet_grid_date_layout);
        }
    }
}
