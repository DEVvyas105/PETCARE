package com.example.admin.petcare.Admin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admin.petcare.Admin.AllPaidPets;
import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.Admin.AdminCustomPaidAdapter;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AdminPaidFragment extends Fragment {
    public AdminPaidFragment() {

    }

    RecyclerView paidGrid;
    SharedPreferences sp;
    ArrayList<AllPaidPets> allPaidPets;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.admin_paid_layout, container, false);

        // Inflate the layout for this fragment
        paidGrid = root.findViewById(R.id.admin_paid_grid);
        paidGrid.setLayoutManager(new LinearLayoutManager(getActivity()));
        paidGrid.setItemAnimator(new DefaultItemAnimator());
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getPaidUserData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
    }

    private class getPaidUserData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("u_type", "Paid");
            hashMap.put("isPurchase", "2");
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getAdoptionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    allPaidPets = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllPaidPets list = new AllPaidPets();
                        list.setId(jsonObject.getString("id"));
                        list.setUserId(jsonObject.getString("userId"));
                        list.setName(jsonObject.getString("u_name"));
                        list.setEmail(jsonObject.getString("u_email"));
                        list.setContactNo(jsonObject.getString("u_cno"));
                        list.setHeight(jsonObject.getString("u_height"));
                        list.setWeight(jsonObject.getString("u_weight"));
                        list.setLifespan(jsonObject.getString("u_lifespan"));
                        list.setPetname(jsonObject.getString("u_petname"));
                        list.setPrice(jsonObject.getString("u_prize"));
                        allPaidPets.add(list);

                    }
                    AdminCustomPaidAdapter adapter = new AdminCustomPaidAdapter(getActivity(), allPaidPets);
                    paidGrid.setAdapter(adapter);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
