package com.example.admin.petcare.buy;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;
import com.squareup.picasso.Picasso;

import net.gotev.uploadservice.MultipartUploadRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.UUID;

public class AddCategoryActivity extends AppCompatActivity {

    ImageView image;
    EditText name;
    Button insert;
    private static final int STORAGE_PERMISSION_CODE = 123;
    private static final int PICK_IMAGE_REQUEST = 1;
    private Bitmap bitmap;
    private Uri filePath;
    SharedPreferences sp;

    String sType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_category);
        requestStoragePermission();
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        image = findViewById(R.id.add_category_image);
        name = findViewById(R.id.add_category_name);
        insert = findViewById(R.id.add_category_insert);

        if (sp.getString(ConstantSp.CATEGORY_ADD_UPDATE, "").equalsIgnoreCase("Add")) {
            getSupportActionBar().setTitle("Add Category");
        } else {
            getSupportActionBar().setTitle("Update Category");
            name.setText(sp.getString(ConstantSp.CATEGORYNAME, ""));
            Picasso.with(AddCategoryActivity.this).load(sp.getString(ConstantSp.CATEGORYIMAGE, "")).into(image);
        }

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= 23) {
                    if (Permission()) {
                        Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(pickPhotoIntent, PICK_IMAGE_REQUEST);
                    } else {
                        Permissioncall();
                    }
                } else {
                    Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhotoIntent, PICK_IMAGE_REQUEST);
                }
            }
        });

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadMultipart();
            }
        });

    }

    private void uploadMultipart() {
        if(sp.getString(ConstantSp.CATEGORY_ADD_UPDATE,"").equalsIgnoreCase("Add")) {
            String path = getImage(filePath);
            if (path != "") {
                //Log.d("RESPONSE",path);
                String uploadId = UUID.randomUUID().toString();
                try {
                    final ProgressDialog pd = new ProgressDialog(AddCategoryActivity.this);
                    pd.setMessage("Please Wait...");
                    pd.setCancelable(false);
                    pd.show();
                    new MultipartUploadRequest(AddCategoryActivity.this, uploadId, ConstantSp.URL + "addCategory.php")
                            .addParameter("userId", sp.getString(ConstantSp.ID, ""))
                            .addParameter("name", name.getText().toString())
                            .addFileToUpload(path, "file")
                            .setMaxRetries(2)
                            .startUpload();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            pd.dismiss();
                            startActivity(new Intent(AddCategoryActivity.this, DashboardActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                        }
                    }, 3000);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "Please Select Image", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            if(sType.equalsIgnoreCase("1")){
                String path = getImage(filePath);
                if (path != "") {
                    //Log.d("RESPONSE",path);
                    String uploadId = UUID.randomUUID().toString();
                    try {
                        final ProgressDialog pd = new ProgressDialog(AddCategoryActivity.this);
                        pd.setMessage("Please Wait...");
                        pd.setCancelable(false);
                        pd.show();
                        new MultipartUploadRequest(AddCategoryActivity.this, uploadId, ConstantSp.URL + "updateCategoryImage.php")
                                .addParameter("categoryId", sp.getString(ConstantSp.CATEGORYID, ""))
                                .addParameter("userId", sp.getString(ConstantSp.ID, ""))
                                .addParameter("name", name.getText().toString())
                                .addFileToUpload(path, "file")
                                .setMaxRetries(2)
                                .startUpload();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                pd.dismiss();
                                startActivity(new Intent(AddCategoryActivity.this, DashboardActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                            }
                        }, 3000);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(this, "Please Select Image", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                if(new ConnectionDetector(AddCategoryActivity.this).isConnectingToInternet()){
                    new updateCategory().execute();
                }
                else{
                    new ConnectionDetector(AddCategoryActivity.this).connectiondetect();
                }
            }
        }
    }

    private String getImage(Uri uri) {
        if (uri != null) {
            String path = null;
            String[] s_array = {MediaStore.Images.Media.DATA};
            Cursor c = managedQuery(uri, s_array, null, null, null);
            int id = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            if (c.moveToFirst()) {
                do {
                    path = c.getString(id);
                }
                while (c.moveToNext());
                c.close();
                if (path != null) {
                    return path;
                }
            }
        }
        return "";
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            //getPath(filePath);
            if (!filePath.equals("")) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                    image.setImageBitmap(bitmap);
                    image.setImageURI(filePath);
                    sType = "1";
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
            }
        } else {
            //Toast.makeText(LoginActivity.this, "Image Not Selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

        }
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }

    private boolean Permission() {
        int permissiocode = ContextCompat.checkSelfPermission(AddCategoryActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permissiocode == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void Permissioncall() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(AddCategoryActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(AddCategoryActivity.this, "write external store..", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(AddCategoryActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }

    private class updateCategory extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AddCategoryActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID,""));
            hashMap.put("categoryId", sp.getString(ConstantSp.CATEGORYID,""));
            hashMap.put("name", name.getText().toString());
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "updateCategory.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(AddCategoryActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddCategoryActivity.this, DashboardActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(AddCategoryActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
