
package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class SignupActivity extends AppCompatActivity {
    Spinner state, city;
    EditText name, email, contact, password, c_password, address, pincod;
    Button register;
    String semail, email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String pwd_pattern = "(?=.*[0-9])(?=.*[a-z])(?=\\S+$).{6,}";
    String spass;

    String[] state_array = {"Select state", "Gujarat", "Maharashtra", "Madhya Pradesh", "Punjab", "Uttar Pradesh",
            "Delhi", "Haryana", "Uttarakhand", "Tamil Nadu", "Goa", "Kerala", "Jammu & Kashmir",
            "Andhra Pradesh", "Rajasthan", "Karnataka", "West Bengal", "Odisha", "Chhattisgarh", "Assam",
            "Himachal Pradesh", "Bihar", "Jharkhand", "Mizoram", "Nagaland", "Telangana", "Arunachal Pradesh",
            "Meghalaya", "Sikkim", "Tripura", "Manipur"};
    String[] city_array = {"Select city", "Surat", "Ahmedabad", "Baroda", "Rajkot", "Himmatnagar", "Gandhinagar", "Mehsana", "Surendranagar", "Bhavnagar"};

    String sGender, sCity, sState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().setTitle("Sign Up");

        state = findViewById(R.id.signup_state);
        city = findViewById(R.id.signup_city);
        name = findViewById(R.id.signup_name);
        email = findViewById(R.id.signup_email);
        contact = findViewById(R.id.signup_cno);
        password = findViewById(R.id.signup_pwd);
        c_password = findViewById(R.id.signup_confirm_pwd);
        register = findViewById(R.id.signup_button);
        address = findViewById(R.id.signup_address);
        pincod = findViewById(R.id.signup_pincode);


        ArrayAdapter city_adapter = new ArrayAdapter(SignupActivity.this, android.R.layout.simple_list_item_1, city_array);
        city.setAdapter(city_adapter);

        city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sCity = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        final ArrayAdapter state_adapter = new ArrayAdapter(SignupActivity.this, android.R.layout.simple_list_item_1, state_array);
        state.setAdapter(state_adapter);

        state.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sState = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                semail = email.getText().toString();
                if (name.getText().toString().equals("")) {
                    name.setError("Please enter your name");
                } else if (email.getText().toString().equalsIgnoreCase("")) {
                    email.setError("Please enter email-id");
                } else if (!semail.matches(email_pattern)) {
                    email.setError("Valid Email Id Required");
                    //Toast.makeText(SignupActivity.this, "Invalid Email", Toast.LENGTH_SHORT).show();
                } else if (contact.getText().toString().equals("")) {
                    contact.setError("Please enter contact number");
                } else if (password.getText().toString().equals("")) {
                    password.setError("Please enter password");
                } else if (c_password.getText().toString().equals("")) {
                    c_password.setError("Please enter confirm password");
                } else if (address.getText().toString().equals("")) {
                    address.setError("Please enter address");
                } else if (pincod.getText().toString().equals("")) {
                    pincod.setError("Please enter pincode");
                } else if (city.getSelectedItemId() <= 0) {

                    Toast.makeText(SignupActivity.this, "Please select city", Toast.LENGTH_LONG).show();
                } else if (state.getSelectedItemId() <= 0) {
                    Toast.makeText(SignupActivity.this, "Please select state", Toast.LENGTH_LONG).show();
                } else {
                    //Toast.makeText(SignupActivity.this,object.getString("Message"),Toast.LENGTH_SHORT).show();
                    /*Intent intent = new Intent(SignupActivity.this,LoginActivity.class);
                    startActivity(intent);*/
                    if (new ConnectionDetector(SignupActivity.this).isConnectingToInternet()) {
                        new insertdata().execute();

                    } else {
                        new ConnectionDetector(SignupActivity.this).connectiondetect();
                    }

                }
            }

        });


    }

    public class insertdata extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(SignupActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")

        @Override
        protected String doInBackground(String... strings) {

            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("name", name.getText().toString());
            hashMap.put("email", email.getText().toString());
            hashMap.put("contact", contact.getText().toString());
            hashMap.put("password", password.getText().toString());
            hashMap.put("address", address.getText().toString());
            hashMap.put("pincode", pincod.getText().toString());
            hashMap.put("state", sState);
            hashMap.put("city", sCity);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "signup.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    Toast.makeText(SignupActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(SignupActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}