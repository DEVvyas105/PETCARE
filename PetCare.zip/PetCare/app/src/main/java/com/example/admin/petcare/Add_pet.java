package com.example.admin.petcare;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

public class Add_pet extends AppCompatActivity {

    EditText user_name, user_email, user_cno, user_pet, user_height, user_weight, user_lifespan, user_prize, fromDate, toDate;
    LinearLayout dateLayout;
    Button add_pet;
    RadioGroup rg;
    RadioButton free, paid;
    String sgender;
    SharedPreferences sp;
    String email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    Calendar fromCalendar,toCalendar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pet);
        getSupportActionBar().setTitle("Add Pet for Adoption");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);
        user_cno = findViewById(R.id.add_contact);
        user_email = findViewById(R.id.add_email);
        user_name = findViewById(R.id.add_username);
        user_pet = findViewById(R.id.add_pet);
        user_height = findViewById(R.id.add_height);
        user_weight = findViewById(R.id.add_weight);
        user_lifespan = findViewById(R.id.add_lifespan);
        user_prize = findViewById(R.id.add_prize);
        add_pet = findViewById(R.id.add_petButton);
        rg = findViewById(R.id.add_rg);
        free = findViewById(R.id.add_free);
        paid = findViewById(R.id.add_paid);

        fromDate = findViewById(R.id.add_pet_from_date);
        toDate = findViewById(R.id.add_pet_to_date);
        dateLayout = findViewById(R.id.add_pet_date_layout);

        fromCalendar = Calendar.getInstance();
        toCalendar = Calendar.getInstance();

        final DatePickerDialog.OnDateSetListener toDateClick = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                toCalendar.set(Calendar.YEAR,i);
                toCalendar.set(Calendar.MONTH,i1);
                toCalendar.set(Calendar.DAY_OF_MONTH,i2);

                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                toDate.setText(format.format(toCalendar.getTime()));

            }
        };

        final DatePickerDialog.OnDateSetListener fromDateClick = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                fromCalendar.set(Calendar.YEAR,i);
                fromCalendar.set(Calendar.MONTH,i1);
                fromCalendar.set(Calendar.DAY_OF_MONTH,i2);

                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
                fromDate.setText(format.format(fromCalendar.getTime()));

            }
        };

        toDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Add_pet.this,toDateClick,toCalendar.get(Calendar.YEAR),toCalendar.get(Calendar.MONTH),toCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        fromDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(Add_pet.this,fromDateClick,fromCalendar.get(Calendar.YEAR),fromCalendar.get(Calendar.MONTH),fromCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        user_name.setText(sp.getString(ConstantSp.NAME, ""));
        user_email.setText(sp.getString(ConstantSp.EMAIL, ""));
        user_cno.setText(sp.getString(ConstantSp.C_NO, ""));

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int id = rg.getCheckedRadioButtonId(); //Male R.id.home_male,R.id.female
                RadioButton rb = findViewById(id);
                sgender = rb.getText().toString();
                if (sgender.equals("Free")) {
                    user_prize.setVisibility(View.GONE);
                    //dateLayout.setVisibility(View.VISIBLE);
                } else if (sgender.equals("Paid")) {
                    user_prize.setVisibility(View.VISIBLE);
                    //dateLayout.setVisibility(View.GONE);
                } else {
                    user_prize.setVisibility(View.GONE);
                    //dateLayout.setVisibility(View.GONE);
                }
            }
        });


        add_pet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user_name.getText().toString().trim().equalsIgnoreCase("")) {
                    user_name.setError("Name Required");
                } else if (user_email.getText().toString().trim().equalsIgnoreCase("")) {
                    user_email.setError("Email Id Required");
                } else if (!user_email.getText().toString().trim().matches(email_pattern)) {
                    user_email.setError("Valid Email Id Required");
                } else if (user_cno.getText().toString().trim().equalsIgnoreCase("")) {
                    user_cno.setError("Contact No. Required");
                } else if (user_cno.getText().toString().length() < 10 || user_cno.getText().toString().length() > 10) {
                    user_cno.setError("Valid Contact No. Required");
                } else if (user_pet.getText().toString().trim().equalsIgnoreCase("")) {
                    user_pet.setError("Type Of Pet Or Name Of Pet Required");
                } else if (user_height.getText().toString().trim().equalsIgnoreCase("")) {
                    user_height.setError("Pet Height Required");
                } else if (user_lifespan.getText().toString().trim().equalsIgnoreCase("")) {
                    user_lifespan.setError("Lifespan Required");
                } else if (user_weight.getText().toString().trim().equalsIgnoreCase("")) {
                    user_weight.setError("Weight Required");
                } else if (rg.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(Add_pet.this, "Please Select Type Of Adoption", Toast.LENGTH_SHORT).show();
                } else {
                    if (sgender.equalsIgnoreCase("Free")) {
                        /*if(fromDate.getText().toString().trim().equalsIgnoreCase("")){
                            Toast.makeText(Add_pet.this, "Please Select From Date", Toast.LENGTH_SHORT).show();
                        }
                        else if(toDate.getText().toString().trim().equalsIgnoreCase("")){
                            Toast.makeText(Add_pet.this, "Please Select To Date", Toast.LENGTH_SHORT).show();
                        }
                        else {*/
                            if (new ConnectionDetector(Add_pet.this).isConnectingToInternet()) {
                                new insertPetdata().execute();

                            } else {
                                new ConnectionDetector(Add_pet.this).connectiondetect();
                            }
                        /*}*/
                    } else {
                        if (user_prize.getText().toString().trim().equalsIgnoreCase("")) {
                            user_prize.setError("Pet Price Required");
                        } else {
                            if (new ConnectionDetector(Add_pet.this).isConnectingToInternet()) {
                                new insertPetdata().execute();

                            } else {
                                new ConnectionDetector(Add_pet.this).connectiondetect();
                            }
                        }
                    }
                }

            }
        });

    }

    public class insertPetdata extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Add_pet.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            hashMap.put("u_name", user_name.getText().toString());
            hashMap.put("u_email", user_email.getText().toString());
            hashMap.put("u_cno", user_cno.getText().toString());
            hashMap.put("u_height", user_height.getText().toString());
            hashMap.put("u_weight", user_weight.getText().toString());
            hashMap.put("u_lifespan", user_lifespan.getText().toString());
            hashMap.put("u_petname", user_pet.getText().toString());
            hashMap.put("u_prize", user_prize.getText().toString());
            hashMap.put("u_from", fromDate.getText().toString());
            hashMap.put("u_to", toDate.getText().toString());
            hashMap.put("u_type", sgender);
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "addUserPetDetails.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(Add_pet.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Add_pet.this, UserActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(Add_pet.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}