package com.example.admin.petcare.Admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.Admin.AdminCustomPaidAdapter;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Admin_payments extends AppCompatActivity {

    RecyclerView paidGrid;
    SharedPreferences sp;
    ArrayList<AllPaidPets> allPaidPets;

    Button totalEarning;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_payments);
        paidGrid = findViewById(R.id.admin_payment_grid);
        paidGrid.setLayoutManager(new LinearLayoutManager(Admin_payments.this));
        paidGrid.setItemAnimator(new DefaultItemAnimator());
        totalEarning = findViewById(R.id.admin_payment_earning);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(Admin_payments.this).isConnectingToInternet()) {
            new getPaidUserData().execute();
        } else {
            new ConnectionDetector(Admin_payments.this).connectiondetect();
        }
    }

    private class getPaidUserData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(Admin_payments.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("u_type", "Paid");
            hashMap.put("isPurchase", "1");
            //hashMap.put("id",sp.getString(ConstantSp.ADOPTIONId,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getAdoptionPets.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    totalEarning.setText("Total Earning : " + object.getInt("total"));
                    JSONArray array = object.getJSONArray("response");
                    allPaidPets = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        AllPaidPets list = new AllPaidPets();
                        list.setId(jsonObject.getString("id"));
                        list.setUserId(jsonObject.getString("userId"));
                        list.setName(jsonObject.getString("u_name"));
                        list.setEmail(jsonObject.getString("u_email"));
                        list.setContactNo(jsonObject.getString("u_cno"));
                        list.setHeight(jsonObject.getString("u_height"));
                        list.setWeight(jsonObject.getString("u_weight"));
                        list.setLifespan(jsonObject.getString("u_lifespan"));
                        list.setPetname(jsonObject.getString("u_petname"));
                        list.setPrice(jsonObject.getString("u_prize"));
                        allPaidPets.add(list);

                    }
                    AdminCustomPaidAdapter adapter = new AdminCustomPaidAdapter(Admin_payments.this, allPaidPets);
                    paidGrid.setAdapter(adapter);

                } else {
                    Toast.makeText(Admin_payments.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
