package com.example.admin.petcare.buy;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.example.admin.petcare.ConnectionDetector;
import com.example.admin.petcare.ConstantSp;
import com.example.admin.petcare.MakeServiceCall;
import com.example.admin.petcare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class HistoryFragment extends Fragment {

    RecyclerView gridView;
    ArrayList<HistoryList> historyLists;
    HistoryAdapter adapter;
    SharedPreferences sp;

    //without shipping id......getorderhistory call

    String[] name = {"Syrup", "Capsule", "Drops"};
    String[] id = {"#0123546", "#456332", "#0234568"}, status = {"pending", "pending", "pending"};
    String[] date = {"12/12/2019", "01/12/2019", "20/11/2019"};

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_history, container, false);
        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        gridView = root.findViewById(R.id.h_gv);
        gridView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new historyData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        historyLists = new ArrayList<>();
        return root;
    }

    private class historyData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("userId",sp.getString(ConstantSp.ID,""));
            hashMap.put("userType",sp.getString(ConstantSp.USERTYPE,""));
            return new MakeServiceCall().MakeServiceCall(ConstantSp.URL + "getorderhistory.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equals("True")) {
                    JSONArray array = object.getJSONArray("response");
                    historyLists = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        HistoryList list = new HistoryList();
                        list.setId(jsonObject.getString("id"));
                        list.setTotalAmount(jsonObject.getString("totalAmount"));
                        list.setStatus(jsonObject.getString("status"));
                        list.setDate(jsonObject.getString("order_date"));
                        historyLists.add(list);
                    }
                    adapter = new HistoryAdapter(getActivity(), historyLists);
                    gridView.setAdapter(adapter);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}